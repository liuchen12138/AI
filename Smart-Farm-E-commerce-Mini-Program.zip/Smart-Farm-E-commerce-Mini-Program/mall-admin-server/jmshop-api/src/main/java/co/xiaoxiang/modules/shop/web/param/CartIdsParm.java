package co.xiaoxiang.modules.shop.web.param;

import lombok.Data;

import java.util.List;

/**
 * @ClassName CartIds
 * @Author hupeng <610796224@qq.com>
 * @Date 2019/11/15
 **/
@Data
public class CartIdsParm {
    List<String> ids;
}
