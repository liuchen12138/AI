package co.xiaoxiang.config;


import co.xiaoxiang.utils.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 数据权限配置
 * @author hupeng
 * @since 2019-10-16
 */
@Component
public class DataScope {


}
