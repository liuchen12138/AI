package co.xiaoxiang.modules.shop.web.param;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

import co.xiaoxiang.common.web.param.QueryParam;

/**
 * <p>
 * 评论表 查询参数对象
 * </p>
 *
 * @author hupeng
 * @date 2019-10-23
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(value="YxStoreProductReplyQueryParam对象", description="评论表查询参数")
public class YxStoreProductReplyQueryParam extends QueryParam {
    private static final long serialVersionUID = 1L;
}
