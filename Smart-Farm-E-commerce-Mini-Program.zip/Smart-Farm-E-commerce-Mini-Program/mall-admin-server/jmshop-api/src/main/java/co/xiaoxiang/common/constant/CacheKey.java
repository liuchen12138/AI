package co.xiaoxiang.common.constant;


public interface CacheKey {
    String ORDER_CANCEL_JOB = "order_cancel_job";

}
