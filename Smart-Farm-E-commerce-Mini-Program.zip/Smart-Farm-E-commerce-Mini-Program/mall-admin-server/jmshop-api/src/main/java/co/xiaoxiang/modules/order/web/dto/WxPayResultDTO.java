package co.xiaoxiang.modules.order.web.dto;

import java.io.Serializable;

/**
 * @ClassName WxPayResultDTO
 * @Author hupeng <610796224@qq.com>
 * @Date 2019/11/6
 **/
public class WxPayResultDTO  implements Serializable {
}
