package co.xiaoxiang.modules.shop.web.param;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

import co.xiaoxiang.common.web.param.QueryParam;

/**
 * <p>
 * 优惠券表 查询参数对象
 * </p>
 *
 * @author hupeng
 * @date 2019-10-27
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(value="YxStoreCouponQueryParam对象", description="优惠券表查询参数")
public class YxStoreCouponQueryParam extends QueryParam {
    private static final long serialVersionUID = 1L;
}
