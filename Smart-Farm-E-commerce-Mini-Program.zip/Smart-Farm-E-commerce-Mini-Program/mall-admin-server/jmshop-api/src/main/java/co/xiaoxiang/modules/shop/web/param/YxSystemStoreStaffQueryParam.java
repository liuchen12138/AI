package co.xiaoxiang.modules.shop.web.param;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

import co.xiaoxiang.common.web.param.QueryParam;

/**
 * <p>
 * 门店店员表 查询参数对象
 * </p>
 *
 * @author hupeng
 * @date 2020-03-23
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(value="YxSystemStoreStaffQueryParam对象", description="门店店员表查询参数")
public class YxSystemStoreStaffQueryParam extends QueryParam {
    private static final long serialVersionUID = 1L;
}
