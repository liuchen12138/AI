# ER图与实体关系

<cite>
**本文档引用文件**  
- [YxUser.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\user\entity\YxUser.java)
- [YxStoreProduct.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\shop\entity\YxStoreProduct.java)
- [YxStoreOrder.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\order\entity\YxStoreOrder.java)
- [YxStoreCart.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\shop\entity\YxStoreCart.java)
- [YxStoreCoupon.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\shop\entity\YxStoreCoupon.java)
- [YxStoreCouponUser.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\shop\entity\YxStoreCouponUser.java)
- [YxStoreOrderCartInfo.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\order\entity\YxStoreOrderCartInfo.java)
- [CouponEnum.java](file://mall-admin-server\jmshop-common\src\main\java\co\xiaoxiang\enums\CouponEnum.java)
- [OrderStatusEnum.java](file://mall-admin-server\jmshop-common\src\main\java\co\xiaoxiang\enums\OrderStatusEnum.java)
- [ProductEnum.java](file://mall-admin-server\jmshop-common\src\main\java\co\xiaoxiang\enums\ProductEnum.java)
</cite>

## 目录
1. [引言](#引言)
2. [核心实体关系概述](#核心实体关系概述)
3. [ER图与实体关系详解](#er图与实体关系详解)
4. [实体关系业务含义解释](#实体关系业务含义解释)
5. [数据库设计建议](#数据库设计建议)

## 引言
本文档旨在为智能农场电商小程序项目提供完整的实体关系图（ER图）文档，展示用户(YxUser)、商品(YxStoreProduct)、订单(YxStoreOrder)、购物车(YxStoreCart)、优惠券(YxStoreCoupon)等核心实体之间的数据关系。通过标准的ER图表示一对一、一对多、多对多关系，并详细标注外键关联，为数据库设计人员和后端开发者提供直观的数据关系视图。

## 核心实体关系概述
本系统的核心业务围绕用户购物流程展开，主要实体包括用户、商品、购物车、订单和优惠券。这些实体之间通过外键建立复杂的关系网络，支持完整的电商功能。系统采用关系型数据库设计，通过外键约束保证数据完整性。

**实体关系概览：**
- 用户(YxUser)与订单(YxStoreOrder)：一对多关系
- 用户(YxUser)与购物车(YxStoreCart)：一对多关系
- 用户(YxUser)与优惠券(YxStoreCouponUser)：一对多关系
- 商品(YxStoreProduct)与订单项：多对多关系（通过订单详情表关联）
- 订单(YxStoreOrder)与购物车(YxStoreCart)：多对多关系（通过订单购物详情表关联）
- 优惠券(YxStoreCoupon)与用户(YxUser)：多对多关系（通过优惠券发放记录表关联）

## ER图与实体关系详解

```mermaid
erDiagram
YxUser ||--o{ YxStoreOrder : "拥有"
YxUser ||--o{ YxStoreCart : "拥有"
YxUser ||--o{ YxStoreCouponUser : "领取"
YxStoreProduct ||--o{ YxStoreCart : "包含"
YxStoreProduct ||--o{ YxStoreOrderCartInfo : "组成"
YxStoreCoupon ||--o{ YxStoreCouponUser : "发放"
YxStoreOrder ||--o{ YxStoreOrderCartInfo : "包含"
YxStoreCart ||--o{ YxStoreOrderCartInfo : "关联"
YxUser {
integer uid PK
string username
string account
string password
string realName
string phone
integer addTime
boolean status
decimal nowMoney
decimal integral
}
YxStoreProduct {
integer id PK
string storeName
string storeInfo
decimal price
decimal otPrice
integer stock
integer sales
integer isHot
integer isNew
integer isBenefit
integer isBest
integer isShow
}
YxStoreOrder {
integer id PK
string orderId
integer uid FK
string realName
string userPhone
string userAddress
string cartId
decimal payPrice
integer paid
integer status
integer addTime
integer payTime
}
YxStoreCart {
integer id PK
integer uid FK
integer productId FK
string productAttrUnique
integer cartNum
integer addTime
integer isPay
}
YxStoreCoupon {
integer id PK
string title
decimal couponPrice
decimal useMinPrice
integer couponTime
boolean status
}
YxStoreCouponUser {
integer id PK
integer cid FK
integer uid FK
decimal couponPrice
integer addTime
integer endTime
integer useTime
integer status
}
YxStoreOrderCartInfo {
integer id PK
integer oid FK
integer cartId FK
string cartInfo
string unique
}
```

**图示关系说明：**
- **一对一关系**：在本系统中较少见，主要用于特定业务场景
- **一对多关系**：最常见关系类型，如一个用户可以有多个订单
- **多对多关系**：通过关联表实现，如订单与商品的多对多关系通过YxStoreOrderCartInfo表实现

**外键关联标注：**
- YxStoreOrder.uid → YxUser.uid：订单与用户的关联
- YxStoreCart.uid → YxUser.uid：购物车与用户的关联
- YxStoreCart.productId → YxStoreProduct.id：购物车与商品的关联
- YxStoreOrderCartInfo.oid → YxStoreOrder.id：订单详情与订单的关联
- YxStoreOrderCartInfo.cartId → YxStoreCart.id：订单详情与购物车的关联
- YxStoreCouponUser.cid → YxStoreCoupon.id：优惠券发放记录与优惠券的关联
- YxStoreCouponUser.uid → YxUser.uid：优惠券发放记录与用户的关联

**Section sources**
- [YxUser.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\user\entity\YxUser.java)
- [YxStoreProduct.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\shop\entity\YxStoreProduct.java)
- [YxStoreOrder.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\order\entity\YxStoreOrder.java)
- [YxStoreCart.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\shop\entity\YxStoreCart.java)
- [YxStoreCoupon.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\shop\entity\YxStoreCoupon.java)
- [YxStoreCouponUser.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\shop\entity\YxStoreCouponUser.java)
- [YxStoreOrderCartInfo.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\order\entity\YxStoreOrderCartInfo.java)

## 实体关系业务含义解释

### 用户与订单关系
一个用户可以创建多个订单，但每个订单只能属于一个用户。这种一对多关系反映了电商系统的基本业务逻辑：用户是订单的发起者和拥有者。订单表中的uid字段作为外键指向用户表的uid主键，确保了订单与用户的关联。

**业务含义：**
- 支持用户查看自己的所有订单历史
- 便于按用户进行订单统计和分析
- 保证订单数据的安全性和归属性

### 用户与购物车关系
一个用户可以有多个购物车记录，每个购物车记录对应一个商品及其数量。这种一对多关系允许用户在下单前将多个商品添加到购物车中。购物车表中的uid字段作为外键指向用户表的uid主键。

**业务含义：**
- 支持用户批量选购商品
- 便于实现购物车的增删改查操作
- 为订单生成提供数据基础

### 商品与订单关系
商品与订单之间是多对多关系，通过YxStoreOrderCartInfo（订单购物详情表）实现关联。一个订单可以包含多个商品，一个商品也可以出现在多个订单中。

**业务含义：**
- 支持订单包含多种商品
- 便于统计商品的销售情况
- 为库存管理提供数据支持

### 优惠券关系
优惠券系统包含两个核心表：YxStoreCoupon（优惠券定义）和YxStoreCouponUser（优惠券发放记录）。两者之间是一对多关系，一个优惠券定义可以发放给多个用户。

**业务含义：**
- 支持营销活动中的优惠券发放
- 记录用户领取和使用优惠券的情况
- 便于优惠券的生命周期管理

### 订单状态管理
订单状态通过枚举类OrderStatusEnum进行管理，包含未支付、待发货、待收货、待评价、已完成、退款中、已退款等状态。

**状态流转：**
- 未支付 → 待发货：用户完成支付
- 待发货 → 待收货：商家发货
- 待收货 → 待评价：用户确认收货
- 待评价 → 已完成：用户完成评价
- 任何状态 → 退款中：用户申请退款
- 退款中 → 已退款：退款完成

**Section sources**
- [YxUser.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\user\entity\YxUser.java)
- [YxStoreOrder.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\order\entity\YxStoreOrder.java)
- [YxStoreCart.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\shop\entity\YxStoreCart.java)
- [YxStoreCoupon.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\shop\entity\YxStoreCoupon.java)
- [YxStoreCouponUser.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\shop\entity\YxStoreCouponUser.java)
- [OrderStatusEnum.java](file://mall-admin-server\jmshop-common\src\main\java\co\xiaoxiang\enums\OrderStatusEnum.java)

## 数据库设计建议

### 表结构优化建议
1. **索引优化**：
   - 在YxStoreOrder表的orderId字段上创建唯一索引
   - 在YxStoreOrder表的uid和addTime字段上创建复合索引，便于按用户和时间查询订单
   - 在YxStoreCart表的uid和isPay字段上创建复合索引，便于查询用户的购物车状态

2. **字段设计**：
   - 金额字段统一使用decimal类型，避免浮点数精度问题
   - 时间字段使用integer存储时间戳，便于跨平台兼容
   - 状态字段使用tinyint或smallint，节省存储空间

3. **外键约束**：
   - 所有外键都应建立相应的约束，保证数据完整性
   - 考虑业务需求，合理设置级联删除和更新策略

### 性能优化建议
1. **查询优化**：
   - 订单详情查询可通过YxStoreOrderCartInfo表关联获取
   - 用户订单统计可通过分组查询实现
   - 商品销售排行可通过聚合函数实现

2. **缓存策略**：
   - 热门商品信息可缓存到Redis
   - 用户购物车数据可缓存到Redis
   - 优惠券信息可缓存到Redis

3. **分库分表建议**：
   - 当订单数据量达到百万级别时，可考虑按用户ID或时间进行分表
   - 购物车数据可根据用户ID进行分表
   - 日志类数据可单独存放

### 数据一致性保障
1. **事务管理**：
   - 订单创建过程应包含商品库存检查、购物车状态更新、订单创建等多个操作，需使用事务保证原子性
   - 优惠券使用需检查有效期和使用条件，使用事务保证数据一致性

2. **并发控制**：
   - 商品库存更新需使用乐观锁或悲观锁防止超卖
   - 购物车操作需考虑并发场景下的数据一致性

3. **数据校验**：
   - 在应用层和数据库层都应进行必要的数据校验
   - 关键业务操作应有日志记录，便于问题追踪

**Section sources**
- [YxStoreOrder.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\order\entity\YxStoreOrder.java)
- [YxStoreCart.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\shop\entity\YxStoreCart.java)
- [YxStoreCoupon.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\shop\entity\YxStoreCoupon.java)
- [YxStoreCouponUser.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\shop\entity\YxStoreCouponUser.java)
- [YxStoreOrderCartInfo.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\order\entity\YxStoreOrderCartInfo.java)