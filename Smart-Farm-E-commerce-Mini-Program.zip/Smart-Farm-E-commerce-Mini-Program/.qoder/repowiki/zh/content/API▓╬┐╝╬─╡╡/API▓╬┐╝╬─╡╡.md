# API参考文档

<cite>
**本文档引用的文件**  
- [SwaggerConfig.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/config/SwaggerConfig.java)
- [ApiResult.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/common/api/ApiResult.java)
- [ApiCode.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/common/api/ApiCode.java)
- [ApiController.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/common/api/ApiController.java)
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java)
- [TokenFilter.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenFilter.java)
- [QueryParam.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/common/web/param/QueryParam.java)
- [OrderQueryParam.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/common/web/param/OrderQueryParam.java)
- [application.yml](file://mall-admin-server/jmshop-system/src/main/resources/config/application.yml)
</cite>

## 目录
1. [简介](#简介)
2. [认证授权机制](#认证授权机制)
3. [统一响应结构](#统一响应结构)
4. [错误码体系](#错误码体系)
5. [分页查询规范](#分页查询规范)
6. [请求头规范](#请求头规范)

## 简介

本API参考文档为智能农场电商小程序提供完整的RESTful API接口说明。基于SwaggerConfig配置，系统化地列出所有公开的API端点，为前端开发者和第三方集成者提供精确的接口调用手册。

**本文档引用的文件**
- [SwaggerConfig.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/config/SwaggerConfig.java#L38-L80)
- [application.yml](file://mall-admin-server/jmshop-system/src/main/resources/config/application.yml#L1-L77)

## 认证授权机制

系统采用JWT（JSON Web Token）进行身份认证和授权。所有需要认证的API接口都必须在请求头中包含有效的JWT令牌。

### 认证流程
1. 用户登录成功后，服务器生成JWT令牌并返回给客户端
2. 客户端在后续请求中将JWT令牌包含在请求头中
3. 服务器验证JWT令牌的有效性，验证通过后处理请求

### JWT配置
根据配置文件，JWT相关配置如下：
- **令牌头名称**：由`jwt.header`配置项指定
- **令牌前缀**：由`jwt.token-start-with`配置项指定，通常为"Bearer "
- **令牌有效期**：在TokenProvider中配置

```mermaid
sequenceDiagram
participant 客户端
participant 服务器
participant TokenProvider
客户端->>服务器 : 发送登录请求(用户名/密码)
服务器->>TokenProvider : 验证用户凭证
TokenProvider-->>服务器 : 返回认证结果
服务器->>服务器 : 创建JWT令牌
服务器-->>客户端 : 返回包含JWT令牌的响应
客户端->>服务器 : 后续请求(包含JWT令牌在Header中)
服务器->>TokenProvider : 验证JWT令牌
TokenProvider-->>服务器 : 返回验证结果
服务器-->>客户端 : 返回请求处理结果
```

**图示来源**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java#L38-L116)
- [TokenFilter.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenFilter.java#L59-L78)

**本节来源**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java#L38-L116)
- [TokenFilter.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenFilter.java#L59-L78)

## 统一响应结构

所有API接口都使用统一的响应封装结构`ApiResult<T>`，确保响应格式的一致性。

### ApiResult结构
```java
public class ApiResult<T> implements Serializable {
    private int status;        // 响应状态码
    private T data;            // 响应数据
    private String msg;        // 响应消息
    private Date time;         // 响应时间
}
```

### 响应字段说明
| 字段 | 类型 | 说明 |
|------|------|------|
| status | int | 响应状态码，具体值参见错误码体系 |
| data | T | 响应数据，根据具体接口返回不同类型的数据 |
| msg | String | 响应消息，对状态码的文本描述 |
| time | Date | 响应时间，格式为"yyyy-MM-dd HH:mm:ss" |

### 使用示例
```java
// 成功响应
{
    "status": 200,
    "data": { /* 具体业务数据 */ },
    "msg": "操作成功",
    "time": "2023-12-01 10:30:45"
}

// 失败响应
{
    "status": 500,
    "data": null,
    "msg": "操作失败",
    "time": "2023-12-01 10:30:45"
}
```

**本节来源**
- [ApiResult.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/common/api/ApiResult.java#L24-L114)
- [ApiController.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/common/api/ApiController.java#L14-L54)

## 错误码体系

系统定义了统一的错误码体系`ApiCode`，用于标准化API响应的状态码。

### 错误码列表
| 错误码 | 说明 | HTTP状态码 |
|--------|------|----------|
| 200 | 操作成功 | 200 |
| 401 | 非法访问 | 401 |
| 403 | 没有权限 | 403 |
| 404 | 你请求的路径不存在 | 404 |
| 500 | 操作失败 | 500 |
| 410000 | 没有权限 | 403 |
| 5000 | 系统异常! | 500 |
| 5001 | 请求参数校验异常 | 400 |
| 5002 | 请求参数解析异常 | 400 |
| 5003 | HTTP Media 类型异常 | 400 |
| 5005 | 系统登录异常 | 401 |

### 错误码使用
```java
public enum ApiCode {
    SUCCESS(200, "操作成功"),
    UNAUTHORIZED(401, "非法访问"),
    NOT_PERMISSION(403, "没有权限"),
    NOT_FOUND(404, "你请求的路径不存在"),
    FAIL(500, "操作失败"),
    SYSTEM_EXCEPTION(5000,"系统异常!"),
    PARAMETER_EXCEPTION(5001,"请求参数校验异常"),
    PARAMETER_PARSE_EXCEPTION(5002,"请求参数解析异常"),
    HTTP_MEDIA_TYPE_EXCEPTION(5003,"HTTP Media 类型异常"),
    SYSTEM_LOGIN_EXCEPTION(5005,"系统登录异常");
    
    private final int code;
    private final String msg;
    
    // getter方法...
}
```

**本节来源**
- [ApiCode.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/common/api/ApiCode.java#L11-L63)

## 分页查询规范

系统采用统一的分页查询规范，所有支持分页的API接口都遵循相同的参数格式。

### 分页参数
所有分页查询都继承自`QueryParam`类，包含以下基本参数：

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| page | Integer | 否 | 1 | 页码，从1开始 |
| limit | Integer | 否 | 10 | 每页显示的数目 |
| keyword | String | 否 | 无 | 搜索关键字 |

### 排序参数
对于支持排序的查询，继承自`OrderQueryParam`类，在基础分页参数上增加排序功能：

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| orders | List<OrderItem> | 否 | 排序规则列表 |

### 分页响应结构
分页查询的响应数据通常包含在`data`字段中，结构如下：
```json
{
    "status": 200,
    "data": {
        "records": [/* 数据列表 */],
        "total": 100,
        "size": 10,
        "current": 1,
        "pages": 10
    },
    "msg": "操作成功",
    "time": "2023-12-01 10:30:45"
}
```

### Swagger分页展示
在Swagger文档中，分页参数会被转换为以下格式展示：
```java
@ApiModel
private static class Page {
    @ApiModelProperty("页码 (0..N)")
    private Integer page;
    
    @ApiModelProperty("每页显示的数目")
    private Integer size;
    
    @ApiModelProperty("以下列格式排序标准：property[,asc | desc]。 默认排序顺序为升序。 支持多种排序条件：如：id,asc")
    private List<String> sort;
}
```

**本节来源**
- [QueryParam.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/common/web/param/QueryParam.java#L13-L39)
- [OrderQueryParam.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/common/web/param/OrderQueryParam.java#L18-L35)
- [SwaggerConfig.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/config/SwaggerConfig.java#L97-L127)

## 请求头规范

所有API请求都需要遵循统一的请求头规范。

### 认证请求头
| 请求头名称 | 值格式 | 说明 |
|-----------|--------|------|
| Authorization | Bearer <JWT令牌> | 用于身份认证，所有需要认证的接口都必须包含此头 |

### 内容类型请求头
| 请求头名称 | 值 | 说明 |
|-----------|-----|------|
| Content-Type | application/json | 请求体为JSON格式时使用 |

### 示例
```
GET /api/user/info HTTP/1.1
Host: example.com
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
Content-Type: application/json
```

**本节来源**
- [SwaggerConfig.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/config/SwaggerConfig.java#L63-L71)
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java#L109-L115)