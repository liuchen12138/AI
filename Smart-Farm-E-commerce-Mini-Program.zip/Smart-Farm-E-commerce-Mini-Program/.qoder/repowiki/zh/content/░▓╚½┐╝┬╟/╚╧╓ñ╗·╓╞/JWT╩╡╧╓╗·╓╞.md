# JWT实现机制

<cite>
**本文档引用的文件**   
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java)
- [TokenFilter.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenFilter.java)
- [JwtAuthenticationEntryPoint.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/JwtAuthenticationEntryPoint.java)
- [SecurityProperties.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/config/SecurityProperties.java)
- [SecurityConfig.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/config/SecurityConfig.java)
- [JwtUser.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/vo/JwtUser.java)
- [OnlineUser.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/vo/OnlineUser.java)
- [OnlineUserService.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/service/OnlineUserService.java)
- [TokenConfigurer.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenConfigurer.java)
</cite>

## 目录
1. [简介](#简介)
2. [核心组件概述](#核心组件概述)
3. [TokenProvider实现机制](#tokenprovider实现机制)
4. [TokenFilter请求拦截机制](#tokenfilter请求拦截机制)
5. [JwtAuthenticationEntryPoint认证失败处理](#jwtauthenticationentrypoint认证失败处理)
6. [JWT令牌结构详解](#jwt令牌结构详解)
7. [安全配置与集成](#安全配置与集成)
8. [在线用户管理](#在线用户管理)
9. [扩展与自定义指南](#扩展与自定义指南)
10. [异常处理机制](#异常处理机制)

## 简介
本文档详细阐述了智能农场电商平台中的JWT实现机制，重点分析了TokenProvider、TokenFilter和JwtAuthenticationEntryPoint三个核心组件。文档涵盖了JWT令牌的生成、解析、验证流程，以及安全配置、在线用户管理等关键功能，为开发者提供全面的技术参考和扩展指导。

## 核心组件概述
系统中的JWT安全机制由多个核心组件协同工作，包括令牌提供者、过滤器、认证入口点、安全配置等。这些组件共同实现了基于JWT的无状态认证体系。

```mermaid
graph TB
A[客户端请求] --> B[TokenFilter]
B --> C{是否存在Token?}
C --> |是| D[解析Token]
D --> E[TokenProvider验证]
E --> F[从Redis获取用户信息]
F --> G[设置SecurityContext]
G --> H[继续请求处理]
C --> |否| I[继续请求处理]
J[认证失败] --> K[JwtAuthenticationEntryPoint]
K --> L[返回401响应]
M[用户登录] --> N[TokenProvider生成Token]
N --> O[OnlineUserService保存在线用户]
O --> P[返回Token给客户端]
style A fill:#f9f,stroke:#333
style H fill:#bbf,stroke:#333
style L fill:#f96,stroke:#333
```

**图示来源**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java)
- [TokenFilter.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenFilter.java)
- [JwtAuthenticationEntryPoint.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/JwtAuthenticationEntryPoint.java)
- [OnlineUserService.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/service/OnlineUserService.java)

**本节来源**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java#L1-L117)
- [TokenFilter.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenFilter.java#L1-L79)
- [JwtAuthenticationEntryPoint.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/JwtAuthenticationEntryPoint.java#L1-L26)

## TokenProvider实现机制
TokenProvider组件负责JWT令牌的生成、解析和验证，是整个JWT机制的核心。它使用HS512算法进行签名，确保令牌的安全性。

### 令牌生成过程
TokenProvider通过`createToken`方法生成JWT令牌，该过程包括设置主题、声明、签名算法和过期时间等关键步骤。

```mermaid
sequenceDiagram
participant Client as "客户端"
participant TokenProvider as "TokenProvider"
participant SecurityProperties as "SecurityProperties"
Client->>TokenProvider : createToken(authentication)
TokenProvider->>TokenProvider : 提取权限信息
TokenProvider->>SecurityProperties : 获取base64密钥
SecurityProperties-->>TokenProvider : 返回密钥
TokenProvider->>TokenProvider : 计算过期时间
TokenProvider->>TokenProvider : 构建JWT令牌
TokenProvider->>TokenProvider : 使用HS512算法签名
TokenProvider-->>Client : 返回JWT令牌
Note over TokenProvider,SecurityProperties : 使用配置的HS512算法和密钥进行签名
```

**图示来源**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java#L46-L60)
- [SecurityProperties.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/config/SecurityProperties.java)

**本节来源**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java#L46-L60)

### 令牌组成结构
JWT令牌由三部分组成：头部(Header)、载荷(Payload)和签名(Signature)，各部分通过点号分隔。

```mermaid
flowchart TD
A[JWT令牌] --> B[Header]
A --> C[Payload]
A --> D[Signature]
B --> B1["alg: HS512"]
B --> B2["typ: JWT"]
C --> C1["sub: 用户名"]
C --> C2["auth: 权限列表"]
C --> C3["exp: 过期时间"]
D --> D1["HMACSHA512(base64UrlEncode(header) + '.' + base64UrlEncode(payload), secret)"]
style A fill:#f9f,stroke:#333
style B fill:#bbf,stroke:#333
style C fill:#bbf,stroke:#333
style D fill:#bbf,stroke:#333
```

**图示来源**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java)
- [SecurityProperties.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/config/SecurityProperties.java)

**本节来源**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java#L54-L59)

### 配置与初始化
TokenProvider通过Spring的InitializingBean接口在初始化时解码密钥，确保密钥的安全存储和使用。

```mermaid
classDiagram
class TokenProvider {
+SecurityProperties properties
-Key key
+afterPropertiesSet()
+createToken(Authentication)
+getAuthentication(String)
+validateToken(String)
+getToken(HttpServletRequest)
}
class SecurityProperties {
+String header
+String tokenStartWith
+String base64Secret
+Long tokenValidityInSeconds
+String onlineKey
}
TokenProvider --> SecurityProperties : "依赖"
TokenProvider ..|> InitializingBean : "实现"
note right of TokenProvider
初始化时通过base64Secret生成HMAC-SHA512密钥
使用HS512算法进行JWT签名
令牌有效期由tokenValidityInSeconds配置
end note
```

**图示来源**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java#L29-L44)
- [SecurityProperties.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/config/SecurityProperties.java#L14-L35)

**本节来源**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java#L29-L44)
- [SecurityProperties.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/config/SecurityProperties.java#L14-L35)

## TokenFilter请求拦截机制
TokenFilter继承自GenericFilterBean，负责在每次请求时拦截并处理JWT令牌，实现无状态的认证机制。

### 请求拦截流程
TokenFilter在每个请求中检查Authorization头，解析并验证JWT令牌，然后将认证信息设置到SecurityContext中。

```mermaid
sequenceDiagram
participant Request as "HTTP请求"
participant TokenFilter as "TokenFilter"
participant TokenProvider as "TokenProvider"
participant OnlineUserService as "OnlineUserService"
participant SecurityContext as "SecurityContextHolder"
Request->>TokenFilter : doFilter()
TokenFilter->>TokenFilter : resolveToken()
TokenFilter->>TokenProvider : validateToken()
TokenProvider-->>TokenFilter : 验证结果
alt 令牌有效
TokenFilter->>OnlineUserService : 获取在线用户信息
OnlineUserService-->>TokenFilter : 返回用户数据
TokenFilter->>SecurityContext : 设置认证信息
SecurityContext-->>TokenFilter : 设置成功
else 令牌无效
TokenFilter->>TokenFilter : 记录调试信息
end
TokenFilter->>Request : 继续过滤链
```

**图示来源**
- [TokenFilter.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenFilter.java#L37-L67)
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java)
- [OnlineUserService.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/service/OnlineUserService.java)

**本节来源**
- [TokenFilter.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenFilter.java#L37-L67)

### 令牌解析逻辑
TokenFilter通过resolveToken方法从请求头中提取JWT令牌，遵循标准的Bearer Token格式。

```mermaid
flowchart TD
A[开始] --> B[获取请求头]
B --> C{"是否存在Authorization头?"}
C --> |否| D[返回null]
C --> |是| E{"是否以Bearer开头?"}
E --> |否| D
E --> |是| F[截取Bearer后的内容]
F --> G[返回令牌字符串]
style A fill:#f9f,stroke:#333
style D fill:#f96,stroke:#333
style G fill:#bbf,stroke:#333
```

**图示来源**
- [TokenFilter.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenFilter.java#L70-L77)
- [SecurityProperties.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/config/SecurityProperties.java)

**本节来源**
- [TokenFilter.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenFilter.java#L70-L77)

## JwtAuthenticationEntryPoint认证失败处理
JwtAuthenticationEntryPoint实现了Spring Security的AuthenticationEntryPoint接口，负责处理认证失败的情况。

### 认证失败响应机制
当用户请求需要认证的资源但未提供有效凭证时，JwtAuthenticationEntryPoint会返回标准的401未授权响应。

```mermaid
sequenceDiagram
participant Request as "客户端请求"
participant SecurityFilter as "安全过滤器链"
participant EntryPoint as "JwtAuthenticationEntryPoint"
participant Response as "HTTP响应"
Request->>SecurityFilter : 访问受保护资源
SecurityFilter->>SecurityFilter : 检测到未认证
SecurityFilter->>EntryPoint : commence()
EntryPoint->>Response : sendError(401)
Response-->>Request : 401 Unauthorized
Note over EntryPoint,Response : 响应包含SC_UNAUTHORIZED状态码<br/>和可选的错误消息
```

**图示来源**
- [JwtAuthenticationEntryPoint.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/JwtAuthenticationEntryPoint.java#L16-L24)

**本节来源**
- [JwtAuthenticationEntryPoint.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/JwtAuthenticationEntryPoint.java#L16-L24)

## JWT令牌结构详解
JWT令牌采用标准化的JSON Web Token格式，包含头部、载荷和签名三个部分，确保了令牌的完整性和安全性。

### 令牌组成部分
JWT令牌由三个Base64Url编码的部分组成，用点号分隔，形成xxx.yyy.zzz的格式。

```mermaid
erDiagram
JWT_TOKEN {
string header
string payload
string signature
}
HEADER {
string alg
string typ
}
PAYLOAD {
string sub
string auth
datetime exp
}
JWT_TOKEN ||--o{ HEADER : "包含"
JWT_TOKEN ||--o{ PAYLOAD : "包含"
class JWT_TOKEN "JWT令牌"
class HEADER "头部"
class PAYLOAD "载荷"
note right of JWT_TOKEN
完整格式: header.payload.signature
各部分使用Base64Url编码
使用HS512算法签名确保完整性
end note
```

**图示来源**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java)
- [SecurityProperties.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/config/SecurityProperties.java)

**本节来源**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java#L54-L59)

### 载荷声明信息
JWT载荷中包含用户的关键信息和权限数据，这些声明用于在无状态会话中识别用户身份。

```mermaid
classDiagram
class JwtUser {
+Long id
+String username
+String nickName
+String avatar
+String phone
+Collection~GrantedAuthority~ authorities
+boolean enabled
+Integer createTime
}
class OnlineUser {
+Long id
+String userName
+String nickName
+String browser
+String ip
+String address
+String key
+Date loginTime
}
JwtUser --> OnlineUser : "映射"
note right of JwtUser
sub : 用户名
auth : 权限列表，逗号分隔
exp : 过期时间戳
这些信息用于构建Authentication对象
end note
```

**图示来源**
- [JwtUser.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/vo/JwtUser.java)
- [OnlineUser.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/vo/OnlineUser.java)
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java)

**本节来源**
- [JwtUser.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/vo/JwtUser.java#L19-L81)
- [OnlineUser.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/vo/OnlineUser.java)

## 安全配置与集成
SecurityConfig类配置了整个应用的安全策略，将JWT机制集成到Spring Security框架中。

### 安全配置结构
SecurityConfig通过继承WebSecurityConfigurerAdapter来定制安全策略，整合了JWT相关的组件。

```mermaid
classDiagram
class SecurityConfig {
+TokenProvider tokenProvider
+CorsFilter corsFilter
+JwtAuthenticationEntryPoint authenticationErrorHandler
+JwtAccessDeniedHandler jwtAccessDeniedHandler
+ApplicationContext applicationContext
+configure(HttpSecurity)
+securityConfigurerAdapter()
}
class WebSecurityConfigurerAdapter {
<<abstract>>
}
SecurityConfig --|> WebSecurityConfigurerAdapter : "继承"
SecurityConfig --> TokenProvider : "注入"
SecurityConfig --> CorsFilter : "注入"
SecurityConfig --> JwtAuthenticationEntryPoint : "注入"
SecurityConfig --> JwtAccessDeniedHandler : "注入"
note right of SecurityConfig
禁用CSRF保护
使用无状态会话管理
配置异常处理机制
应用TokenConfigurer
end note
```

**图示来源**
- [SecurityConfig.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/config/SecurityConfig.java)
- [TokenConfigurer.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenConfigurer.java)

**本节来源**
- [SecurityConfig.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/config/SecurityConfig.java#L36-L148)

### HTTP安全配置
configure方法定义了详细的HTTP安全规则，包括异常处理、头部设置、会话管理和请求授权等。

```mermaid
flowchart TD
A[开始配置] --> B[禁用CSRF]
B --> C[添加CORS过滤器]
C --> D[配置异常处理]
D --> E[禁用iframe]
E --> F[无状态会话]
F --> G[请求授权]
G --> H[静态资源放行]
G --> I[Swagger放行]
G --> J[匿名访问放行]
G --> K[其他请求认证]
K --> L[应用TokenConfigurer]
style A fill:#f9f,stroke:#333
style H fill:#bbf,stroke:#333
style I fill:#bbf,stroke:#333
style J fill:#bbf,stroke:#333
style K fill:#f96,stroke:#333
```

**图示来源**
- [SecurityConfig.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/config/SecurityConfig.java#L65-L142)

**本节来源**
- [SecurityConfig.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/config/SecurityConfig.java#L65-L142)

## 在线用户管理
系统通过OnlineUserService和Redis结合，实现了在线用户的跟踪和管理功能。

### 在线用户数据流
用户登录后，其信息被保存到Redis中，TokenFilter在每次请求时从Redis获取用户信息。

```mermaid
sequenceDiagram
participant User as "用户"
participant Login as "登录接口"
participant TokenProvider as "TokenProvider"
participant OnlineUserService as "OnlineUserService"
participant Redis as "Redis存储"
User->>Login : 提交凭证
Login->>TokenProvider : 生成Token
TokenProvider-->>Login : 返回Token
Login->>OnlineUserService : save()
OnlineUserService->>Redis : 存储在线用户
Redis-->>OnlineUserService : 存储成功
OnlineUserService-->>Login : 保存成功
Login-->>User : 返回Token和用户信息
Note over OnlineUserService,Redis : 使用onlineKey前缀存储<br/>设置与令牌相同的过期时间
```

**图示来源**
- [OnlineUserService.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/service/OnlineUserService.java#L46-L57)
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java)

**本节来源**
- [OnlineUserService.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/service/OnlineUserService.java#L46-L57)

### 在线用户实体结构
OnlineUser类定义了在线用户信息的数据结构，包括用户基本信息和会话信息。

```mermaid
classDiagram
class OnlineUser {
+Long id
+String userName
+String nickName
+String browser
+String ip
+String address
+String key
+Date loginTime
}
class JwtUser {
+Long id
+String username
+String nickName
+Collection~GrantedAuthority~ authorities
+boolean enabled
}
OnlineUser <-- JwtUser : "基于"
note right of OnlineUser
id : 用户ID
userName : 用户名
browser : 浏览器信息
ip : IP地址
address : 地理位置
key : 加密的令牌
loginTime : 登录时间
end note
```

**图示来源**
- [OnlineUser.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/vo/OnlineUser.java)
- [JwtUser.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/vo/JwtUser.java)
- [OnlineUserService.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/service/OnlineUserService.java)

**本节来源**
- [OnlineUser.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/vo/OnlineUser.java)
- [OnlineUserService.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/service/OnlineUserService.java#L50-L56)

## 扩展与自定义指南
本节提供JWT机制的扩展和自定义指导，帮助开发者根据具体需求进行调整。

### 自定义JWT负载内容
开发者可以通过修改TokenProvider的createToken方法来扩展JWT令牌的负载内容。

```mermaid
flowchart TD
A[原始createToken] --> B[获取权限信息]
B --> C[设置过期时间]
C --> D[构建基础JWT]
D --> E{"是否需要扩展?"}
E --> |是| F[添加自定义声明]
F --> G[如: 用户ID, 角色, 租户等]
G --> H[完成JWT构建]
E --> |否| H
H --> I[返回令牌]
style E fill:#f9f,stroke:#333
style F fill:#bbf,stroke:#333
style G fill:#bbf,stroke:#333
```

**本节来源**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java#L46-L60)

### 更改加密算法
系统当前使用HS512算法，但可以通过修改TokenProvider的签名部分来使用其他算法。

```mermaid
classDiagram
class SignatureAlgorithm {
<<enumeration>>
HS256
HS384
HS512
RS256
RS384
RS512
}
class TokenProvider {
-Key key
+createToken()
}
TokenProvider --> SignatureAlgorithm : "使用"
note right of TokenProvider
当前使用SignatureAlgorithm.HS512
可替换为其他算法如RS512
需相应调整密钥生成方式
end note
```

**本节来源**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java#L57)
- [SecurityProperties.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/config/SecurityProperties.java)

## 异常处理机制
系统实现了完善的JWT相关异常处理，确保在各种异常情况下都能提供适当的响应。

### 令牌验证异常类型
TokenProvider的validateToken方法处理多种JWT相关的异常情况。

```mermaid
flowchart TD
A[validateToken] --> B[解析JWT]
B --> C{"是否成功?"}
C --> |是| D[返回true]
C --> |否| E[捕获异常]
E --> F{异常类型}
F --> |SecurityException| G[签名无效]
F --> |MalformedJwtException| H[令牌格式错误]
F --> |ExpiredJwtException| I[令牌过期]
F --> |UnsupportedJwtException| J[不支持的令牌]
F --> |IllegalArgumentException| K[参数错误]
G --> L[记录日志]
H --> L
I --> L
J --> L
K --> L
L --> M[返回false]
style A fill:#f9f,stroke:#333
style D fill:#bbf,stroke:#333
style M fill:#f96,stroke:#333
```

**图示来源**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java#L89-L106)

**本节来源**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java#L89-L106)

### 异常处理流程
系统通过分层的异常处理机制，确保不同类型的异常得到适当的处理。

```mermaid
graph TB
A[JWT异常] --> B[TokenProvider]
B --> C{异常类型}
C --> |签名问题| D[记录"Invalid JWT signature"]
C --> |格式问题| E[记录"Malformed JWT token"]
C --> |过期问题| F[记录"Expired JWT token"]
C --> |不支持| G[记录"Unsupported JWT token"]
C --> |参数问题| H[记录"JWT token compact invalid"]
D --> I[返回false]
E --> I
F --> I
G --> I
H --> I
I --> J[TokenFilter继续处理]
J --> K{令牌有效?}
K --> |否| L[不设置SecurityContext]
K --> |是| M[设置SecurityContext]
L --> N[可能触发认证入口点]
N --> O[JwtAuthenticationEntryPoint]
O --> P[返回401响应]
style A fill:#f9f,stroke:#333
style I fill:#bbf,stroke:#333
style P fill:#f96,stroke:#333
```

**图示来源**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java#L89-L106)
- [TokenFilter.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenFilter.java#L51-L66)
- [JwtAuthenticationEntryPoint.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/JwtAuthenticationEntryPoint.java#L16-L24)

**本节来源**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java#L89-L106)
- [TokenFilter.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenFilter.java#L51-L66)
- [JwtAuthenticationEntryPoint.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/JwtAuthenticationEntryPoint.java#L16-L24)