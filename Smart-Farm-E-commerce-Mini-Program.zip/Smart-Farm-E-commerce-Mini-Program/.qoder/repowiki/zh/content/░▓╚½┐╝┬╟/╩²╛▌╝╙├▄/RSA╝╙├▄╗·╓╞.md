# RSA加密机制

<cite>
**本文档引用的文件**   
- [RsaUtils.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/utils/RsaUtils.java)
- [RsaProperties.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/config/RsaProperties.java)
- [AuthController.java](file://mall-admin-server/jmshop-system/src/main/java/co/xiaoxiang/modules/security/rest/AuthController.java)
- [UserController.java](file://mall-admin-server/jmshop-system/src/main/java/co/xiaoxiang/modules/system/rest/UserController.java)
</cite>

## 目录
1. [引言](#引言)
2. [核心组件分析](#核心组件分析)
3. [RsaUtils类功能详解](#rsautils类功能详解)
4. [RsaProperties配置类分析](#rsaproperties配置类分析)
5. [系统应用场景](#系统应用场景)
6. [密钥安全管理策略](#密钥安全管理策略)
7. [性能影响及优化建议](#性能影响及优化建议)
8. [结论](#结论)

## 引言
本项目采用RSA非对称加密机制来保障系统的安全性，主要应用于用户密码传输、敏感数据保护和接口签名验证等场景。系统通过RsaUtils工具类提供完整的RSA加密、解密、签名和验签功能，同时通过RsaProperties配置类管理密钥相关参数。在用户登录和修改密码等关键操作中，前端使用公钥对敏感信息进行加密，后端使用私钥进行解密，有效防止了敏感信息在传输过程中的泄露风险。

## 核心组件分析
系统中的RSA加密机制主要由两个核心组件构成：RsaUtils工具类和RsaProperties配置类。RsaUtils类封装了RSA加密算法的所有核心功能，包括公钥加密、私钥解密、私钥签名和公钥验签等操作。RsaProperties类则负责管理RSA加密所需的配置参数，特别是私钥的存储和获取。这两个组件协同工作，为系统提供了安全可靠的非对称加密服务。

**Section sources**
- [RsaUtils.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/utils/RsaUtils.java#L22-L186)
- [RsaProperties.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/config/RsaProperties.java#L13-L21)

## RsaUtils类功能详解
RsaUtils类是系统中RSA加密功能的核心实现，提供了完整的非对称加密操作接口。

### 公钥加密与私钥解密
RsaUtils类实现了标准的RSA公钥加密私钥解密流程。`encryptByPublicKey`方法使用公钥对明文进行加密，`decryptByPrivateKey`方法使用私钥对密文进行解密。该功能主要用于前端对敏感数据（如密码）进行加密传输，后端进行解密处理。

```mermaid
sequenceDiagram
participant 前端 as 前端应用
participant 后端 as 后端服务
participant RsaUtils as RsaUtils工具类
前端->>后端 : 请求公钥
后端-->>前端 : 返回公钥
前端->>前端 : 使用公钥加密敏感数据
前端->>后端 : 发送加密数据
后端->>RsaUtils : 调用decryptByPrivateKey
RsaUtils-->>后端 : 返回解密结果
后端-->>前端 : 处理结果
```

**Diagram sources**
- [RsaUtils.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/utils/RsaUtils.java#L136-L144)
- [RsaUtils.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/utils/RsaUtils.java#L119-L127)

### 私钥加密与公钥解密
除了标准的公钥加密私钥解密模式，RsaUtils还支持私钥加密公钥解密的模式。`encryptByPrivateKey`方法使用私钥对数据进行加密，`decryptByPublicKey`方法使用公钥对数据进行解密。这种模式通常用于数字签名场景，确保数据的完整性和不可否认性。

### 密钥对生成
`generateKeyPair`方法用于生成RSA密钥对。该方法使用Java的KeyPairGenerator生成1024位的RSA密钥对，并将公钥和私钥分别编码为Base64字符串格式，便于存储和传输。生成的密钥对包含公钥和私钥两个部分，公钥可以公开分发，私钥必须严格保密。

```mermaid
classDiagram
class RsaUtils {
+static final String SRC
+main(String[] args)
+test1(RsaKeyPair keyPair)
+test2(RsaKeyPair keyPair)
+decryptByPublicKey(String publicKeyText, String text)
+encryptByPrivateKey(String privateKeyText, String text)
+decryptByPrivateKey(String privateKeyText, String text)
+encryptByPublicKey(String publicKeyText, String text)
+generateKeyPair()
}
class RsaKeyPair {
-String publicKey
-String privateKey
+RsaKeyPair(String publicKey, String privateKey)
+getPublicKey()
+getPrivateKey()
}
RsaUtils --> RsaKeyPair : 返回
```

**Diagram sources**
- [RsaUtils.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/utils/RsaUtils.java#L152-L161)
- [RsaUtils.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/utils/RsaUtils.java#L167-L185)

**Section sources**
- [RsaUtils.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/utils/RsaUtils.java#L22-L186)

## RsaProperties配置类分析
RsaProperties配置类负责管理RSA加密相关的配置参数，特别是私钥的存储和获取。

### 配置属性
RsaProperties类定义了一个静态的privateKey字段，用于存储系统的私钥。通过Spring的@Value注解，从配置文件中读取rsa.private_key属性值，并通过setPrivateKey方法将其赋值给静态字段。这种方式确保了私钥可以在应用程序的任何地方被访问，同时通过配置文件进行管理，提高了安全性。

### 配置管理
私钥的配置通过外部化配置实现，可以在application.yml或其他配置文件中设置rsa.private_key属性。这种设计使得私钥的管理更加灵活，可以在不同环境（开发、测试、生产）中使用不同的私钥，同时避免了将敏感信息硬编码在代码中。

```mermaid
classDiagram
class RsaProperties {
+static String privateKey
+setPrivateKey(String privateKey)
}
RsaProperties --> RsaUtils : 提供私钥
RsaUtils --> RsaProperties : 获取私钥
```

**Diagram sources**
- [RsaProperties.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/config/RsaProperties.java#L15-L20)

**Section sources**
- [RsaProperties.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/config/RsaProperties.java#L13-L21)

## 系统应用场景
RSA加密机制在系统中有多个关键应用场景，主要用于保护敏感数据的安全。

### 用户登录密码加密
在用户登录过程中，前端获取服务器提供的公钥，使用公钥对用户输入的密码进行加密，然后将加密后的密码发送到服务器。服务器使用私钥对密码进行解密，然后与数据库中存储的哈希值进行比对。这种方式有效防止了密码在传输过程中被窃取。

```mermaid
sequenceDiagram
participant 用户 as 用户
participant 前端 as 前端应用
participant 后端 as 后端服务
用户->>前端 : 输入用户名和密码
前端->>后端 : 请求公钥
后端-->>前端 : 返回公钥
前端->>前端 : 使用公钥加密密码
前端->>后端 : 发送用户名和加密密码
后端->>后端 : 使用私钥解密密码
后端->>后端 : 验证用户凭证
后端-->>前端 : 返回认证结果
前端-->>用户 : 显示登录结果
```

**Diagram sources**
- [AuthController.java](file://mall-admin-server/jmshop-system/src/main/java/co/xiaoxiang/modules/security/rest/AuthController.java#L74-L75)

### 用户修改密码
当用户修改密码时，前端同样使用公钥对新旧密码进行加密，然后发送到服务器。服务器使用私钥解密密码，验证旧密码的正确性，并将新密码加密后存储到数据库中。这个过程确保了密码在传输过程中的安全性。

```mermaid
sequenceDiagram
participant 用户 as 用户
participant 前端 as 前端应用
participant 后端 as 后端服务
用户->>前端 : 输入旧密码和新密码
前端->>前端 : 使用公钥加密旧密码和新密码
前端->>后端 : 发送加密的旧密码和新密码
后端->>后端 : 使用私钥解密密码
后端->>后端 : 验证旧密码
后端->>后端 : 加密存储新密码
后端-->>前端 : 返回结果
前端-->>用户 : 显示结果
```

**Diagram sources**
- [UserController.java](file://mall-admin-server/jmshop-system/src/main/java/co/xiaoxiang/modules/system/rest/UserController.java#L171-L172)

### 敏感数据保护
除了密码，系统中的其他敏感数据（如邮箱、手机号等）也可以使用RSA加密进行保护。在数据传输过程中，这些敏感信息都经过公钥加密，确保即使数据被截获，也无法被轻易解密。

**Section sources**
- [AuthController.java](file://mall-admin-server/jmshop-system/src/main/java/co/xiaoxiang/modules/security/rest/AuthController.java#L74-L85)
- [UserController.java](file://mall-admin-server/jmshop-system/src/main/java/co/xiaoxiang/modules/system/rest/UserController.java#L171-L180)

## 密钥安全管理策略
系统的密钥安全管理策略是确保RSA加密机制安全性的关键。

### 密钥存储
私钥通过配置文件进行管理，使用Spring的@Value注解从配置文件中读取。这种设计避免了将私钥硬编码在代码中，降低了私钥泄露的风险。公钥则可以在需要时通过密钥对生成算法动态生成，或者从证书中提取。

### 访问控制
私钥的访问受到严格控制，只有经过授权的组件才能访问。RsaProperties类中的privateKey字段被声明为私有，并通过受控的方法进行设置和获取。这种封装确保了私钥不会被意外暴露。

### 密钥轮换
系统支持密钥轮换机制。通过更新配置文件中的私钥值，可以实现密钥的平滑过渡。在密钥轮换期间，系统可以同时支持新旧两套密钥，确保服务的连续性，然后逐步淘汰旧密钥。

### 泄露应对
一旦发生密钥泄露，应立即采取以下措施：
1. 生成新的密钥对
2. 更新配置文件中的私钥
3. 通知所有客户端获取新的公钥
4. 对受影响的用户进行安全提醒
5. 检查系统日志，确定泄露范围和影响

**Section sources**
- [RsaProperties.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/config/RsaProperties.java#L15-L20)
- [RsaUtils.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/utils/RsaUtils.java#L152-L161)

## 性能影响及优化建议
RSA加密算法作为一种非对称加密算法，其性能特性需要特别关注。

### 性能特点
RSA加密算法的计算复杂度较高，特别是私钥解密操作。加密和解密的时间与密钥长度成正比，1024位密钥的性能表现已经可以满足大多数应用场景的需求。然而，对于高并发系统，RSA加密可能成为性能瓶颈。

### 优化建议
1. **密钥长度选择**：当前系统使用1024位密钥，在安全性和性能之间取得了良好平衡。如果安全性要求更高，可以考虑升级到2048位，但需要评估性能影响。

2. **缓存机制**：对于频繁使用的公钥，可以考虑在前端进行缓存，避免每次都需要从服务器获取。

3. **批量处理**：对于需要加密的大量数据，可以考虑使用RSA加密一个对称密钥，然后使用该对称密钥加密实际数据，这样可以显著提高性能。

4. **异步处理**：在非关键路径上，可以考虑将加密解密操作异步化，避免阻塞主线程。

5. **硬件加速**：在高并发场景下，可以考虑使用支持加密指令集的CPU或专用加密硬件来加速RSA运算。

**Section sources**
- [RsaUtils.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/utils/RsaUtils.java#L154-L155)

## 结论
本系统的RSA加密机制设计合理，有效地保护了用户敏感信息的安全。通过RsaUtils工具类和RsaProperties配置类的协同工作，实现了完整的非对称加密功能。在用户登录和修改密码等关键场景中，RSA加密确保了密码在传输过程中的安全性。系统的密钥管理策略也较为完善，通过配置文件管理私钥，避免了硬编码带来的安全风险。未来可以考虑引入更长的密钥长度或结合对称加密算法，以进一步提升系统的安全性和性能。