# API调用

<cite>
**本文档引用的文件**  
- [main.js](file://mp-weixin/common/main.js)
- [vendor.js](file://mp-weixin/common/vendor.js)
- [index.js](file://mp-weixin/config/index.js)
</cite>

## 目录

1. [简介](#简介)
2. [项目结构](#项目结构)
3. [核心组件](#核心组件)
4. [架构概述](#架构概述)
5. [详细组件分析](#详细组件分析)
6. [依赖分析](#依赖分析)
7. [性能考虑](#性能考虑)
8. [故障排除指南](#故障排除指南)
9. [结论](#结论)

## 简介
本文档全面文档化了智慧农庄电商小程序中前端API调用的封装与使用规范。重点说明了基于`wx.request`的网络请求工具类设计，包括请求与响应拦截、错误处理、自动重试等机制。同时解释了JWT认证在请求头中的传递方式与token刷新策略，提供了不同类型API的调用示例，并介绍了性能优化技巧和调试方法。

## 项目结构
该项目是一个典型的微信小程序项目，包含后台管理服务、前端UI和小程序客户端。API调用相关的代码主要位于小程序客户端的`mp-weixin`目录下，特别是`common`目录中的核心文件。

```mermaid
graph TB
subgraph "小程序前端"
A[mp-weixin]
B[common/main.js]
C[common/vendor.js]
D[config/index.js]
end
subgraph "后台服务"
E[mall-admin-server]
F[jmshop-api]
G[数据库]
end
A --> E
B --> C
C --> D
```

**Diagram sources**
- [main.js](file://mp-weixin/common/main.js)
- [vendor.js](file://mp-weixin/common/vendor.js)
- [index.js](file://mp-weixin/config/index.js)

**Section sources**
- [main.js](file://mp-weixin/common/main.js)
- [vendor.js](file://mp-weixin/common/vendor.js)

## 核心组件
小程序的API调用核心是基于flyio库封装的HTTP请求工具，通过拦截器模式实现了请求/响应拦截、错误处理和认证管理。该封装位于`vendor.js`文件中，提供了一致的API调用接口。

**Section sources**
- [vendor.js](file://mp-weixin/common/vendor.js#L13800-L14599)

## 架构概述
API调用架构采用分层设计，上层应用通过封装后的请求方法发起调用，中间层处理认证、拦截和错误，底层使用微信小程序的`wx.request`API进行实际的网络通信。

```mermaid
graph TB
A[应用层] --> B[API封装层]
B --> C[拦截器层]
C --> D[flyio库]
D --> E[wx.request]
E --> F[后端API]
style A fill:#f9f,stroke:#333
style B fill:#bbf,stroke:#333
style C fill:#f96,stroke:#333
style D fill:#9f9,stroke:#333
style E fill:#99f,stroke:#333
style F fill:#6f9,stroke:#333
```

**Diagram sources**
- [vendor.js](file://mp-weixin/common/vendor.js#L13800-L14599)

## 详细组件分析

### API请求封装分析
API请求封装实现了完整的HTTP客户端功能，支持GET、POST等方法，并集成了认证和错误处理机制。

#### 请求拦截与认证
```mermaid
sequenceDiagram
participant App as 应用
participant Request as 请求封装
participant Interceptor as 拦截器
participant API as 后端API
App->>Request : 发起API调用
Request->>Interceptor : 请求拦截
Interceptor->>Interceptor : 添加JWT Token
Interceptor->>Interceptor : 检查登录状态
Interceptor->>API : 发送请求
API-->>Interceptor : 返回响应
Interceptor->>Interceptor : 检查响应状态
Interceptor->>Request : 处理响应
Request-->>App : 返回结果
```

**Diagram sources**
- [vendor.js](file://mp-weixin/common/vendor.js#L13800-L13853)

#### 错误处理流程
```mermaid
flowchart TD
A[发起请求] --> B{请求成功?}
B --> |是| C{状态码200?}
B --> |否| D[网络错误]
C --> |是| E[返回数据]
C --> |否| F{状态码401/403?}
F --> |是| G[跳转登录]
F --> |否| H[显示错误信息]
D --> I[提示网络问题]
G --> J[清除登录状态]
H --> K[显示错误提示]
I --> L[返回失败]
J --> L
K --> L
E --> M[处理成功响应]
```

**Diagram sources**
- [vendor.js](file://mp-weixin/common/vendor.js#L13826-L13853)

### JWT认证机制
系统使用JWT（JSON Web Token）进行用户认证，token通过请求头的Authorization字段传递。

**Section sources**
- [vendor.js](file://mp-weixin/common/vendor.js#L13800-L13806)

## 依赖分析
API调用功能依赖于多个核心模块和第三方库，形成了完整的依赖链。

```mermaid
graph LR
A[应用代码] --> B[API封装]
B --> C[flyio库]
C --> D[wx.request]
B --> E[cookie管理]
B --> F[工具函数]
E --> G[登录状态管理]
F --> H[路由处理]
style A fill:#f9f,stroke:#333
style B fill:#bbf,stroke:#333
style C fill:#9f9,stroke:#333
style D fill:#99f,stroke:#333
style E fill:#ff9,stroke:#333
style F fill:#9ff,stroke:#333
style G fill:#f96,stroke:#333
style H fill:#6f9,stroke:#333
```

**Diagram sources**
- [vendor.js](file://mp-weixin/common/vendor.js)
- [main.js](file://mp-weixin/common/main.js)

**Section sources**
- [vendor.js](file://mp-weixin/common/vendor.js)
- [main.js](file://mp-weixin/common/main.js)

## 性能考虑
虽然本文档主要关注API调用的封装，但性能优化是API设计的重要方面。建议在实际使用中考虑请求合并、缓存策略和分页加载等优化技巧。

## 故障排除指南
当遇到API调用问题时，可以使用微信开发者工具的Network面板进行调试，检查请求参数、响应数据和网络状态。

**Section sources**
- [vendor.js](file://mp-weixin/common/vendor.js#L13800-L14599)

## 结论
该小程序的API调用封装设计合理，通过flyio库提供了强大的HTTP客户端功能，结合微信小程序的原生API，实现了完整的网络请求解决方案。JWT认证机制确保了接口的安全性，拦截器模式使得请求处理逻辑清晰可维护。