# API网关模块

<cite>
**本文档引用的文件**
- [ApiRun.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/ApiRun.java)
- [BaseController.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/common/web/controller/BaseController.java)
- [ApiController.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/common/api/ApiController.java)
- [GlobalExceptionHandler.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/exception/handler/GlobalExceptionHandler.java)
- [SecurityConfig.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/config/SecurityConfig.java)
- [SpringContextHolder.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/utils/SpringContextHolder.java)
- [SwaggerConfig.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/config/SwaggerConfig.java)
- [pom.xml](file://mall-admin-server/jmshop-api/pom.xml)
</cite>

## 目录
1. [简介](#简介)
2. [项目结构](#项目结构)
3. [核心组件](#核心组件)
4. [架构概述](#架构概述)
5. [详细组件分析](#详细组件分析)
6. [依赖分析](#依赖分析)
7. [性能考虑](#性能考虑)
8. [故障排除指南](#故障排除指南)
9. [结论](#结论)

## 简介
API网关模块（jmshop-api）作为系统的核心入口和API聚合点，负责统一管理所有业务模块的API请求。该模块基于Spring Boot框架构建，实现了请求路由、版本管理、安全认证和统一响应处理等功能。通过集成Swagger文档生成工具，提供了完善的API文档支持。本模块聚合了shop、mp、tools等多个业务模块，为前端应用提供统一的API访问接口。

## 项目结构
jmshop-api模块采用标准的Maven项目结构，包含Java源代码、资源文件和测试代码。源代码主要分为配置、控制器、实体、映射器和服务等包，遵循分层架构设计原则。

```mermaid
graph TD
subgraph "jmshop-api"
A[启动类 ApiRun.java]
B[配置包 config]
C[控制器包 controller]
D[实体包 entity]
E[映射器包 mapper]
F[服务包 service]
G[资源文件 resources]
end
```

**图示来源**
- [ApiRun.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/ApiRun.java)
- [pom.xml](file://mall-admin-server/jmshop-api/pom.xml)

**本节来源**
- [ApiRun.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/ApiRun.java)
- [pom.xml](file://mall-admin-server/jmshop-api/pom.xml)

## 核心组件

API网关模块的核心组件包括启动类ApiRun、基础控制器BaseController、统一响应处理机制和全局异常处理器。这些组件共同构成了系统的入口点和核心处理逻辑。

**本节来源**
- [ApiRun.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/ApiRun.java)
- [BaseController.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/common/web/controller/BaseController.java)
- [ApiController.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/common/api/ApiController.java)

## 架构概述

API网关模块采用Spring Boot微服务架构，作为系统的统一入口点，负责聚合多个业务模块的API接口。该模块通过Spring MVC处理HTTP请求，利用Spring Security实现安全认证，并通过MyBatis-Plus与数据库交互。

```mermaid
graph TB
subgraph "前端应用"
A[小程序]
B[Web应用]
end
subgraph "API网关 jmshop-api"
C[ApiRun 启动类]
D[SecurityConfig 安全配置]
E[BaseController 基础控制器]
F[GlobalExceptionHandler 全局异常处理器]
end
subgraph "业务模块"
G[jmshop-shop]
H[jmshop-mp]
I[jmshop-tools]
end
A --> C
B --> C
C --> G
C --> H
C --> I
```

**图示来源**
- [ApiRun.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/ApiRun.java)
- [SecurityConfig.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/config/SecurityConfig.java)
- [pom.xml](file://mall-admin-server/jmshop-api/pom.xml)

## 详细组件分析

### 启动类分析
ApiRun.java是API网关模块的启动类，负责初始化Spring Boot应用上下文。该类使用了多个Spring Boot注解来配置应用行为。

```mermaid
classDiagram
class ApiRun {
+main(String[] args) void
+springContextHolder() SpringContextHolder
}
<<Spring Boot Application>> ApiRun
ApiRun --> SpringContextHolder : "注入"
```

**图示来源**
- [ApiRun.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/ApiRun.java)
- [SpringContextHolder.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/utils/SpringContextHolder.java)

**本节来源**
- [ApiRun.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/ApiRun.java)

### 基础控制器分析
BaseController提供了通用的请求处理功能，所有业务控制器都继承自该类。它封装了获取当前请求和响应对象的方法，简化了控制器的开发。

```mermaid
classDiagram
class BaseController {
+getRequest() HttpServletRequest
+getResponse() HttpServletResponse
}
class ApiController {
+ok(T data) ApiResult~T~
+fail(String msg) ApiResult~Object~
+fail(ApiCode apiCode) ApiResult~Object~
}
BaseController --> ApiController : "继承"
ApiController --> ApiResult : "使用"
```

**图示来源**
- [BaseController.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/common/web/controller/BaseController.java)
- [ApiController.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/common/api/ApiController.java)

**本节来源**
- [BaseController.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/common/web/controller/BaseController.java)
- [ApiController.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/common/api/ApiController.java)

### 异常处理机制分析
全局异常处理器GlobalExceptionHandler统一处理系统中所有未捕获的异常，确保API返回格式的一致性。

```mermaid
flowchart TD
Start([异常发生]) --> CheckExceptionType["判断异常类型"]
CheckExceptionType --> |BadRequestException| HandleBadRequest["返回400错误"]
CheckExceptionType --> |EntityNotFoundException| HandleEntityNotFound["返回404错误"]
CheckExceptionType --> |MethodArgumentNotValidException| HandleValidation["返回参数验证错误"]
CheckExceptionType --> |其他异常| HandleGeneral["返回500错误"]
HandleBadRequest --> End([返回统一格式])
HandleEntityNotFound --> End
HandleValidation --> End
HandleGeneral --> End
```

**图示来源**
- [GlobalExceptionHandler.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/exception/handler/GlobalExceptionHandler.java)

**本节来源**
- [GlobalExceptionHandler.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/exception/handler/GlobalExceptionHandler.java)

## 依赖分析

API网关模块依赖于多个内部和外部组件，形成了完整的功能体系。

```mermaid
graph TD
A[jmshop-api] --> B[jmshop-tools]
A --> C[jmshop-mp]
A --> D[jmshop-shop]
A --> E[Spring Boot]
A --> F[MyBatis-Plus]
A --> G[JWT]
A --> H[Swagger]
A --> I[Redis]
B --> J[工具类]
C --> K[微信模块]
D --> L[商城模块]
E --> M[Spring MVC]
F --> N[数据库访问]
G --> O[身份认证]
H --> P[API文档]
I --> Q[缓存]
```

**图示来源**
- [pom.xml](file://mall-admin-server/jmshop-api/pom.xml)
- [ApiRun.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/ApiRun.java)

**本节来源**
- [pom.xml](file://mall-admin-server/jmshop-api/pom.xml)

## 性能考虑

API网关模块在设计时考虑了性能优化，通过缓存、异步处理和连接池等技术提高系统响应速度。使用了@EnableCaching注解启用Spring缓存，通过@MapperScan优化MyBatis映射器扫描。同时，配置了P6Spy用于SQL语句监控，便于性能调优。

## 故障排除指南

当API网关模块出现问题时，可以按照以下步骤进行排查：

1. 检查应用启动日志，确认Spring上下文是否正常加载
2. 验证数据库连接配置是否正确
3. 检查Redis服务是否正常运行
4. 查看安全配置是否阻止了合法请求
5. 确认Swagger配置是否正确以生成API文档

**本节来源**
- [ApiRun.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/ApiRun.java)
- [SecurityConfig.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/config/SecurityConfig.java)
- [SwaggerConfig.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/config/SwaggerConfig.java)

## 结论

API网关模块作为系统的核心入口，成功实现了API聚合、统一认证和标准化响应处理。通过合理的架构设计和组件划分，该模块具有良好的可维护性和扩展性。未来可以进一步优化性能，增加更多的监控和告警功能，提高系统的稳定性和可靠性。