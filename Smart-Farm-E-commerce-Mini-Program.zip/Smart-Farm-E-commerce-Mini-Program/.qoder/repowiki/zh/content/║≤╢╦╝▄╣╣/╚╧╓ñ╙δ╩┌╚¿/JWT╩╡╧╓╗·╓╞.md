# JWT实现机制

<cite>
**本文档引用的文件**   
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java)
- [TokenFilter.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenFilter.java)
- [SecurityProperties.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/config/SecurityProperties.java)
- [SecurityConfig.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/config/SecurityConfig.java)
- [AuthController.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/rest/AuthController.java)
- [OnlineUserService.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/service/OnlineUserService.java)
- [RedisUtils.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/utils/RedisUtils.java)
- [JwtAuthenticationEntryPoint.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/JwtAuthenticationEntryPoint.java)
- [JwtAccessDeniedHandler.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/JwtAccessDeniedHandler.java)
</cite>

## 目录
1. [简介](#简介)
2. [核心组件](#核心组件)
3. [TokenProvider令牌生成与验证](#tokenprovider令牌生成与验证)
4. [TokenFilter过滤器机制](#tokenfilter过滤器机制)
5. [JWT令牌结构与无状态认证](#jwt令牌结构与无状态认证)
6. [安全最佳实践](#安全最佳实践)
7. [异常处理流程](#异常处理流程)
8. [配置参数说明](#配置参数说明)

## 简介
本项目采用JWT（JSON Web Token）实现无状态认证机制，通过TokenProvider类生成和验证JWT令牌，结合Spring Security框架实现安全控制。系统使用HS512算法进行签名，将用户身份信息编码到令牌中，并通过Redis存储在线用户信息以支持令牌吊销和续期功能。整个认证流程包括令牌生成、请求拦截、令牌验证和安全上下文设置等关键环节。

## 核心组件
系统JWT实现主要由以下几个核心组件构成：
- **TokenProvider**: 负责JWT令牌的生成、解析和验证
- **TokenFilter**: 拦截HTTP请求并处理JWT令牌
- **SecurityConfig**: 配置Spring Security安全策略
- **OnlineUserService**: 管理在线用户信息，与Redis交互
- **SecurityProperties**: JWT相关配置参数
- **RedisUtils**: Redis操作工具类

这些组件协同工作，实现了完整的JWT认证流程。

**Section sources**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java)
- [TokenFilter.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenFilter.java)
- [SecurityConfig.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/config/SecurityConfig.java)

## TokenProvider令牌生成与验证
TokenProvider类是JWT实现的核心，负责令牌的生成、解析和验证。

### 令牌生成
```mermaid
sequenceDiagram
participant AuthController
participant TokenProvider
participant Authentication
participant Jwts
AuthController->>TokenProvider : createToken(authentication)
TokenProvider->>Authentication : 获取用户权限
Authentication-->>TokenProvider : authorities
TokenProvider->>TokenProvider : 构建JWT Claims
TokenProvider->>Jwts : 使用HS512算法签名
Jwts-->>TokenProvider : 生成JWT令牌
TokenProvider-->>AuthController : 返回JWT令牌
```

**Diagram sources**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java#L46-L60)
- [AuthController.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/rest/AuthController.java#L124)

令牌生成过程包含以下步骤：
1. 从Authentication对象获取用户权限信息
2. 设置令牌主题（Subject）为用户名
3. 在claim中存储权限信息
4. 使用HS512算法和密钥进行签名
5. 设置过期时间
6. 生成紧凑的JWT字符串

### 令牌验证
```mermaid
flowchart TD
Start([开始验证]) --> ParseToken["解析JWT令牌"]
ParseToken --> ValidateSignature["验证签名有效性"]
ValidateSignature --> IsValid{"签名有效?"}
IsValid --> |是| CheckExpiration["检查过期时间"]
IsValid --> |否| ReturnInvalid["返回无效令牌"]
CheckExpiration --> IsExpired{"已过期?"}
IsExpired --> |是| ReturnExpired["返回过期令牌"]
IsExpired --> |否| ExtractClaims["提取Claims信息"]
ExtractClaims --> CreateAuthentication["创建Authentication对象"]
CreateAuthentication --> ReturnValid["返回有效认证"]
ReturnInvalid --> End([结束])
ReturnExpired --> End
ReturnValid --> End
```

**Diagram sources**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java#L89-L107)

令牌验证流程包括：
- 验证JWT签名的完整性
- 检查令牌是否过期
- 验证令牌格式是否正确
- 处理各种异常情况（签名错误、过期、不支持的令牌等）

**Section sources**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java)

## TokenFilter过滤器机制
TokenFilter是Spring Security过滤器链中的关键组件，负责拦截请求并处理JWT令牌。

```mermaid
sequenceDiagram
participant Request
participant TokenFilter
participant TokenProvider
participant SecurityContext
participant OnlineUserService
Request->>TokenFilter : HTTP请求
TokenFilter->>TokenFilter : 从Header提取JWT
TokenFilter->>OnlineUserService : 查询Redis中的在线用户
OnlineUserService-->>TokenFilter : 返回用户信息
TokenFilter->>TokenProvider : 验证令牌有效性
TokenProvider-->>TokenFilter : 验证结果
alt 令牌有效
TokenFilter->>SecurityContext : 设置Authentication
SecurityContext-->>TokenFilter : 安全上下文更新
else 令牌无效
TokenFilter->>TokenFilter : 记录调试信息
end
TokenFilter->>Request : 继续处理请求
```

**Diagram sources**
- [TokenFilter.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenFilter.java#L37-L67)
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java#L89-L107)

TokenFilter的工作流程：
1. 从HTTP请求头中提取JWT令牌
2. 通过OnlineUserService查询Redis获取在线用户信息
3. 使用TokenProvider验证令牌的有效性
4. 如果令牌有效，创建Authentication对象并设置到Spring Security上下文中
5. 如果令牌无效，记录日志并继续请求处理

**Section sources**
- [TokenFilter.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenFilter.java)

## JWT令牌结构与无状态认证
### JWT令牌结构
JWT令牌由三部分组成，用点号（.）分隔：

```mermaid
erDiagram
JWT_TOKEN {
string header
string payload
string signature
}
JWT_TOKEN ||--o{ HEADER : "包含"
JWT_TOKEN ||--o{ PAYLOAD : "包含"
JWT_TOKEN ||--o{ SIGNATURE : "包含"
HEADER {
string alg
string typ
}
PAYLOAD {
string sub
string auth
datetime exp
string jti
}
SIGNATURE {
string signature
}
```

**Diagram sources**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java#L54-L59)

**Header（头部）**:
- `alg`: 签名算法，本系统使用HS512
- `typ`: 令牌类型，JWT

**Payload（负载）**:
- `sub`: 主题，存储用户名
- `auth`: 自定义声明，存储用户权限
- `exp`: 过期时间
- `jti`: JWT ID，确保令牌唯一性

**Signature（签名）**:
使用HS512算法和密钥对头部和负载进行签名，确保令牌的完整性和防篡改性。

### 无状态认证优势
```mermaid
graph TD
A[传统Session认证] --> B[服务器存储Session]
A --> C[需要Session复制]
A --> D[扩展性差]
A --> E[跨域困难]
F[JWT无状态认证] --> G[客户端存储令牌]
F --> H[服务器无状态]
F --> I[易于扩展]
F --> J[天然支持跨域]
style A fill:#f9f,stroke:#333
style F fill:#bbf,stroke:#333
```

**Diagram sources**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java)
- [TokenFilter.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenFilter.java)

无状态认证的主要优势：
- **可扩展性**: 服务器无需存储会话状态，易于水平扩展
- **跨域支持**: 令牌可以轻松在不同域之间传递
- **性能优势**: 减少了服务器端的存储和查询开销
- **移动友好**: 适合移动端应用，减少网络往返

**Section sources**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java)
- [TokenFilter.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenFilter.java)

## 安全最佳实践
### 密钥管理
系统使用Base64编码的密钥进行HS512签名，密钥长度要求至少88位。密钥通过SecurityProperties配置，确保了密钥的安全性和可配置性。

### 令牌吊销机制
```mermaid
sequenceDiagram
participant User
participant AuthController
participant OnlineUserService
participant Redis
User->>AuthController : 发起登出请求
AuthController->>OnlineUserService : 调用logout方法
OnlineUserService->>Redis : 删除Redis中的令牌记录
Redis-->>OnlineUserService : 删除确认
OnlineUserService-->>AuthController : 操作完成
AuthController-->>User : 返回登出成功
Note over Redis,OnlineUserService : 令牌从Redis中删除后即失效
```

**Diagram sources**
- [OnlineUserService.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/service/OnlineUserService.java#L123-L126)
- [RedisUtils.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/utils/RedisUtils.java#L34-L43)

通过将JWT令牌与Redis中的在线用户信息关联，实现了令牌的吊销机制。当用户登出或管理员踢出用户时，对应的Redis记录被删除，使令牌失效。

### 令牌续期机制
系统实现了智能的令牌续期机制，当令牌的剩余有效期小于指定阈值时自动续期：

```mermaid
flowchart TD
Start([开始续期检查]) --> GetExpireTime["获取令牌过期时间"]
GetExpireTime --> CalculateDiffer["计算当前时间与过期时间差"]
CalculateDiffer --> IsWithinDetect{"时间差 ≤ 检测阈值?"}
IsWithinDetect --> |是| RenewToken["延长Redis过期时间"]
IsWithinDetect --> |否| NoRenew["无需续期"]
RenewToken --> UpdateRedis["更新Redis过期时间"]
UpdateRedis --> End([续期完成])
NoRenew --> End
```

**Diagram sources**
- [TokenProvider.java](file://mall-admin-server/jmshop-system/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java#L89-L100)
- [SecurityProperties.java](file://mall-admin-server/jmshop-system/src/main/java/co/xiaoxiang/modules/security/config/SecurityProperties.java#L35-L39)

### 防止重放攻击
系统通过以下方式防止重放攻击：
- 令牌包含过期时间，限制了令牌的有效期
- 使用唯一的JWT ID（jti）确保每个令牌的唯一性
- 通过Redis存储令牌状态，支持快速吊销

**Section sources**
- [TokenProvider.java](file://mall-admin-server/jmshop-system/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java#L61-L63)
- [OnlineUserService.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/service/OnlineUserService.java)
- [RedisUtils.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/utils/RedisUtils.java)

## 异常处理流程
系统实现了完善的异常处理机制，确保各种JWT相关异常都能被正确处理。

```mermaid
graph TD
A[JWT验证异常] --> B{异常类型}
B --> C[SecurityException<br>签名无效]
B --> D[MalformedJwtException<br>格式错误]
B --> E[ExpiredJwtException<br>已过期]
B --> F[UnsupportedJwtException<br>不支持的类型]
B --> G[IllegalArgumentException<br>参数错误]
C --> H[记录日志<br>返回无效签名]
D --> I[记录日志<br>返回格式错误]
E --> J[记录日志<br>返回过期令牌]
F --> K[记录日志<br>返回不支持类型]
G --> L[记录日志<br>返回参数错误]
style A fill:#f96,stroke:#333
style C fill:#f66,stroke:#333
style D fill:#f66,stroke:#333
style E fill:#f66,stroke:#333
style F fill:#f66,stroke:#333
style G fill:#f66,stroke:#333
```

**Diagram sources**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java#L90-L106)
- [JwtAuthenticationEntryPoint.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/JwtAuthenticationEntryPoint.java)
- [JwtAccessDeniedHandler.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/JwtAccessDeniedHandler.java)

异常处理策略：
- **签名无效**: 认为令牌被篡改，拒绝访问
- **格式错误**: 令牌格式不符合JWT标准，拒绝访问
- **已过期**: 令牌超过有效期，要求重新认证
- **不支持的类型**: 令牌类型不被系统支持
- **参数错误**: 请求参数存在问题

未捕获的认证异常由JwtAuthenticationEntryPoint处理，返回401 Unauthorized响应；访问被拒绝的异常由JwtAccessDeniedHandler处理，返回403 Forbidden响应。

**Section sources**
- [TokenProvider.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/TokenProvider.java#L89-L107)
- [JwtAuthenticationEntryPoint.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/JwtAuthenticationEntryPoint.java)
- [JwtAccessDeniedHandler.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/security/JwtAccessDeniedHandler.java)

## 配置参数说明
系统通过SecurityProperties类集中管理JWT相关配置参数：

```mermaid
classDiagram
class SecurityProperties {
+String header
+String tokenStartWith
+String base64Secret
+Long tokenValidityInSeconds
+String onlineKey
+String codeKey
+Long detect
+Long renew
+String getTokenStartWith()
}
note right of SecurityProperties
JWT配置参数类
所有参数通过application.yml配置
end
```

**Diagram sources**
- [SecurityProperties.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/config/SecurityProperties.java)

**关键配置参数**:

| 参数 | 说明 | 示例值 |
|------|------|--------|
| `header` | HTTP头名称 | Authorization |
| `tokenStartWith` | 令牌前缀 | Bearer |
| `base64Secret` | Base64编码的密钥 | 长度至少88位 |
| `tokenValidityInSeconds` | 令牌有效期（毫秒） | 604800000 (7天) |
| `onlineKey` | Redis中在线用户键前缀 | online-token- |
| `detect` | 令牌续期检测阈值（毫秒） | 1800000 (30分钟) |
| `renew` | 令牌续期时间（毫秒） | 86400000 (1天) |

这些参数通过Spring Boot的@ConfigurationProperties机制从配置文件中加载，支持灵活的环境配置。

**Section sources**
- [SecurityProperties.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/security/config/SecurityProperties.java)
- [SecurityProperties.java](file://mall-admin-server/jmshop-system/src/main/java/co/xiaoxiang/modules/security/config/SecurityProperties.java)