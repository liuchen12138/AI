# 数据模型与ORM

<cite>
**本文档引用的文件**
- [ApiRun.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/ApiRun.java)
- [User.java](file://mall-admin-server/jmshop-system/src/main/java/co/xiaoxiang/modules/system/domain/User.java)
- [BaseEntity.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/base/BaseEntity.java)
- [YxStoreProduct.java](file://mall-admin-server/jmshop-shop/src/main/java/co/xiaoxiang/modules/shop/domain/YxStoreProduct.java)
- [YxStoreCategory.java](file://mall-admin-server/jmshop-shop/src/main/java/co/xiaoxiang/modules/shop/domain/YxStoreCategory.java)
- [YxStoreProductMapper.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/shop/mapper/YxStoreProductMapper.java)
- [YxStoreProductMapper.xml](file://mall-admin-server/jmshop-api/src/main/resources/mapper/shop/YxStoreProductMapper.xml)
- [BaseServiceImpl.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/shop/service/impl/BaseServiceImpl.java)
</cite>

## 目录
1. [引言](#引言)
2. [项目结构](#项目结构)
3. [核心组件](#核心组件)
4. [架构概述](#架构概述)
5. [详细组件分析](#详细组件分析)
6. [依赖分析](#依赖分析)
7. [性能考虑](#性能考虑)
8. [故障排除指南](#故障排除指南)
9. [结论](#结论)

## 引言
本文档旨在全面解析智能农场电商小程序项目中的数据模型与ORM框架设计。重点分析实体类（如YxUser、YxStoreProduct）的设计原则，包括JPA注解使用、字段定义和关系映射。同时对比分析MyBatis-Plus与JPA两种ORM框架在项目中的共存策略：JPA用于jmshop-shop模块的Repository模式，MyBatis-Plus用于复杂SQL查询场景。文档还将说明Mapper接口与XML映射文件（如YxStoreProductMapper.xml）的协作机制，并提供实体映射、复杂查询和性能优化的实践案例。

## 项目结构
该项目采用多模块Maven架构，主要分为前端和后端两大组成部分。后端服务采用Spring Boot框架构建，包含多个功能模块，如jmshop-api、jmshop-common、jmshop-shop等。数据访问层采用了JPA和MyBatis-Plus两种ORM框架共存的策略，以满足不同场景的需求。

```mermaid
graph TB
subgraph "前端"
MP[微信小程序]
UI[管理后台界面]
end
subgraph "后端"
API[jmshop-api]
SHOP[jmshop-shop]
COMMON[jmshop-common]
SYSTEM[jmshop-system]
end
MP --> API
UI --> API
API --> SHOP
API --> COMMON
API --> SYSTEM
```

**图示来源**
- [ApiRun.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/ApiRun.java#L1-L32)

**章节来源**
- [ApiRun.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/ApiRun.java#L1-L32)

## 核心组件
本项目的核心数据模型组件包括实体类（Entity）、数据访问对象（Repository/Mapper）、服务层（Service）和基础类（BaseEntity）。其中，YxStoreProduct作为商品核心实体，体现了完整的JPA注解设计模式；BaseEntity提供了所有实体共用的基础字段和行为；MyBatis-Plus的Mapper接口与XML文件配合实现了复杂的查询需求。

**章节来源**
- [YxStoreProduct.java](file://mall-admin-server/jmshop-shop/src/main/java/co/xiaoxiang/modules/shop/domain/YxStoreProduct.java#L1-L254)
- [BaseEntity.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/base/BaseEntity.java#L1-L51)

## 架构概述
系统采用分层架构设计，数据访问层创新性地融合了JPA和MyBatis-Plus两种ORM框架。JPA主要用于实体关系映射和基本CRUD操作，遵循Repository模式；而MyBatis-Plus则用于处理复杂的SQL查询，通过Mapper接口和XML映射文件实现。

```mermaid
graph TD
A[Controller] --> B[Service]
B --> C[JPA Repository]
B --> D[MyBatis-Plus Mapper]
C --> E[数据库]
D --> E
F[实体类] --> C
F --> D
```

**图示来源**
- [ApiRun.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/ApiRun.java#L20)
- [YxStoreProduct.java](file://mall-admin-server/jmshop-shop/src/main/java/co/xiaoxiang/modules/shop/domain/YxStoreProduct.java#L22-L24)

## 详细组件分析

### 实体类设计分析
项目中的实体类设计遵循JPA规范，通过注解实现数据库表的映射。以YxStoreProduct为例，展示了完整的JPA注解使用模式。

#### JPA注解使用模式
```mermaid
classDiagram
class YxStoreProduct {
+Integer id
+Integer merId
+String image
+String sliderImage
+String storeName
+String storeInfo
+BigDecimal price
+BigDecimal otPrice
+BigDecimal postage
+Integer sort
+Integer sales
+Integer stock
+Integer isShow
+Integer isHot
+String description
+Integer addTime
+BigDecimal giveIntegral
+BigDecimal cost
+Integer isSeckill
+Integer isBargain
+Integer ficti
+Integer browse
+String codePath
+copy(YxStoreProduct) void
}
class BaseEntity {
+Boolean isDelete
+Timestamp createTime
+Timestamp updateTime
+toString() String
}
class YxStoreCategory {
+Integer id
+String categoryName
+String pic
+Integer pid
+Integer sort
+Integer isShow
+Integer isDel
+Integer addTime
}
YxStoreProduct --> BaseEntity : "继承"
YxStoreProduct --> YxStoreCategory : "ManyToOne"
YxStoreCategory --> YxStoreCategory : "Self-Reference"
```

**图示来源**
- [YxStoreProduct.java](file://mall-admin-server/jmshop-shop/src/main/java/co/xiaoxiang/modules/shop/domain/YxStoreProduct.java#L22-L254)
- [BaseEntity.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/base/BaseEntity.java#L19)
- [YxStoreCategory.java](file://mall-admin-server/jmshop-shop/src/main/java/co/xiaoxiang/modules/shop/domain/YxStoreCategory.java#L1-L50)

#### 字段定义与约束
实体类的字段定义体现了严谨的数据验证和数据库映射策略：

- **主键映射**：使用`@Id`和`@GeneratedValue`注解定义自增主键
- **字段约束**：通过`@NotBlank`、`@NotNull`、`@Min`等注解实现数据验证
- **数据库映射**：使用`@Column`注解精确控制字段属性，如`nullable`、`columnDefinition`等
- **时间戳管理**：利用`@CreationTimestamp`和`@UpdateTimestamp`自动管理创建和更新时间

**章节来源**
- [YxStoreProduct.java](file://mall-admin-server/jmshop-shop/src/main/java/co/xiaoxiang/modules/shop/domain/YxStoreProduct.java#L27-L254)
- [BaseEntity.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/base/BaseEntity.java#L23-L32)

#### 关系映射策略
项目采用了多种JPA关系映射策略：

- **继承关系**：YxStoreProduct继承BaseEntity，共享基础字段
- **多对一关系**：YxStoreProduct与YxStoreCategory之间的一对多/多对一关系
- **懒加载策略**：使用`FetchType.LAZY`实现关联实体的延迟加载
- **外键管理**：通过`@JoinColumn`明确指定外键字段

```mermaid
erDiagram
YX_STORE_PRODUCT {
int id PK
int mer_id
string image
string slider_image
string store_name
string store_info
decimal price
decimal ot_price
decimal postage
int cate_id FK
int is_show
int is_hot
int is_benefit
int is_best
int is_new
text description
int add_time
int is_postage
int is_del
decimal give_integral
decimal cost
int is_seckill
int is_bargain
int ficti
int browse
string code_path
}
YX_STORE_CATEGORY {
int id PK
string category_name
string pic
int pid
int sort
int is_show
int is_del
int add_time
}
YX_STORE_PRODUCT ||--o{ YX_STORE_CATEGORY : "belongs to"
```

**图示来源**
- [YxStoreProduct.java](file://mall-admin-server/jmshop-shop/src/main/java/co/xiaoxiang/modules/shop/domain/YxStoreProduct.java#L76-L79)
- [YxStoreCategory.java](file://mall-admin-server/jmshop-shop/src/main/java/co/xiaoxiang/modules/shop/domain/YxStoreCategory.java#L1-L50)

### ORM框架共存策略
项目创新性地采用了JPA与MyBatis-Plus双ORM框架共存的策略，充分发挥各自优势。

#### JPA与MyBatis-Plus对比分析
```mermaid
graph TD
A[JPA Repository模式] --> |优点| B[面向对象设计]
A --> |优点| C[自动SQL生成]
A --> |优点| D[事务管理]
A --> |缺点| E[复杂查询困难]
A --> |适用场景| F[jmshop-shop模块<br>基本CRUD操作]
G[MyBatis-Plus] --> |优点| H[SQL灵活性]
G --> |优点| I[复杂查询支持]
G --> |优点| J[XML映射]
G --> |缺点| K[需要手动编写SQL]
G --> |适用场景| L[复杂SQL查询<br>性能敏感操作]
```

**章节来源**
- [ApiRun.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/ApiRun.java#L20)
- [YxStoreProductMapper.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/shop/mapper/YxStoreProductMapper.java#L1-L46)

#### MyBatis-Plus实现机制
MyBatis-Plus通过接口与XML文件的协作实现复杂查询：

```mermaid
sequenceDiagram
participant Service as "Service层"
participant Mapper as "Mapper接口"
participant XML as "Mapper XML"
participant DB as "数据库"
Service->>Mapper : 调用查询方法
Mapper->>XML : 映射到SQL语句
XML->>DB : 执行SQL查询
DB-->>XML : 返回结果集
XML-->>Mapper : 映射结果对象
Mapper-->>Service : 返回查询结果
Note over Mapper,XML : 方法名与SQL id对应<br>参数与#{}占位符匹配
```

**图示来源**
- [YxStoreProductMapper.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/shop/mapper/YxStoreProductMapper.java#L25-L45)
- [YxStoreProductMapper.xml](file://mall-admin-server/jmshop-api/src/main/resources/mapper/shop/YxStoreProductMapper.xml#L1-L100)

#### Mapper接口与XML协作
Mapper接口与XML映射文件的协作机制是MyBatis-Plus的核心：

- **接口定义**：在Java接口中声明方法，使用`@Param`注解标识参数
- **XML映射**：在XML文件中定义对应的SQL语句，通过id与接口方法对应
- **动态SQL**：利用`<if>`、`<where>`等标签实现条件查询
- **结果映射**：自动将结果集映射到实体对象

**章节来源**
- [YxStoreProductMapper.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/shop/mapper/YxStoreProductMapper.java#L1-L46)
- [YxStoreProductMapper.xml](file://mall-admin-server/jmshop-api/src/main/resources/mapper/shop/YxStoreProductMapper.xml#L1-L100)

## 依赖分析
项目通过合理的依赖管理实现了ORM框架的共存。

```mermaid
graph TD
A[jmshop-api] --> B[jmshop-shop]
A --> C[jmshop-common]
B --> D[Spring Data JPA]
A --> E[MyBatis-Plus]
C --> F[Lombok]
C --> G[Hibernate]
style A fill:#f9f,stroke:#333
style B fill:#bbf,stroke:#333
style C fill:#bbf,stroke:#333
```

**图示来源**
- [ApiRun.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/ApiRun.java#L4-L10)
- [pom.xml](file://mall-admin-server/jmshop-api/pom.xml#L1-L100)

**章节来源**
- [ApiRun.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/ApiRun.java#L1-L32)
- [pom.xml](file://mall-admin-server/jmshop-api/pom.xml#L1-L100)

## 性能考虑
在ORM框架选择和使用上，项目考虑了多种性能优化策略：

- **查询优化**：简单查询使用JPA，复杂查询使用MyBatis-Plus
- **懒加载**：对关联实体使用`FetchType.LAZY`避免N+1查询问题
- **缓存机制**：通过`@EnableCaching`启用Spring缓存
- **批量操作**：MyBatis-Plus支持批量插入和更新操作
- **索引优化**：在常用查询字段上建立数据库索引

## 故障排除指南
在使用双ORM框架时可能遇到的常见问题及解决方案：

- **事务管理冲突**：确保JPA和MyBatis-Plus使用相同的事务管理器
- **实体映射冲突**：避免同一实体被两种框架同时管理
- **性能瓶颈**：监控慢查询，优化复杂SQL语句
- **配置错误**：检查`@MapperScan`注解的包路径是否正确
- **依赖冲突**：确保JPA和MyBatis-Plus的版本兼容

**章节来源**
- [ApiRun.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/ApiRun.java#L17-L20)
- [BaseServiceImpl.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/shop/service/impl/BaseServiceImpl.java#L1-L50)

## 结论
本项目通过创新性地结合JPA和MyBatis-Plus两种ORM框架，实现了灵活性与效率的平衡。JPA的Repository模式简化了基本CRUD操作，而MyBatis-Plus则提供了处理复杂查询的能力。实体类设计遵循JPA规范，通过丰富的注解实现精确的数据库映射。这种双框架共存策略既保持了代码的可维护性，又满足了复杂业务场景下的性能需求，为电商系统的数据访问提供了稳健的解决方案。