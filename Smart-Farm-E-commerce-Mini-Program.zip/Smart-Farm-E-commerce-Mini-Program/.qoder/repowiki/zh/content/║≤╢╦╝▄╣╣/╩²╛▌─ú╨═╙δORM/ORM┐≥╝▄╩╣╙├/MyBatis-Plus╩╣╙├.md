# MyBatis-Plus使用

<cite>
**本文档引用文件**  
- [MybatisPlusConfig.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/config/MybatisPlusConfig.java)
- [BaseServiceImpl.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/common/service/impl/BaseServiceImpl.java)
- [BaseMapper.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/base/BaseMapper.java)
- [YxStoreProductMapper.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/shop/mapper/YxStoreProductMapper.java)
- [YxStoreProductMapper.xml](file://mall-admin-server/jmshop-api/src/main/resources/mapper/shop/YxStoreProductMapper.xml)
- [YxStoreProductServiceImpl.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/shop/service/impl/YxStoreProductServiceImpl.java)
</cite>

## 目录
1. [简介](#简介)
2. [项目结构](#项目结构)
3. [核心组件](#核心组件)
4. [架构概述](#架构概述)
5. [详细组件分析](#详细组件分析)
6. [依赖分析](#依赖分析)
7. [性能考虑](#性能考虑)
8. [故障排除指南](#故障排除指南)
9. [结论](#结论)

## 简介
本文档详细介绍了在Smart Farm电子商务小程序项目中MyBatis-Plus的集成与高级功能应用。文档重点阐述了MyBatis-Plus的BaseMapper继承机制、通用CRUD方法的使用、XML映射文件的编写规范，以及分页插件、性能分析插件和乐观锁插件的配置与使用。

## 项目结构
该项目采用模块化设计，MyBatis-Plus相关代码主要分布在`jmshop-api`和`jmshop-common`模块中。核心的Mapper接口位于`modules`包下的各个业务模块中，XML映射文件存放在`resources/mapper`目录下，而MyBatis-Plus的配置和基础服务实现则位于`common`包中。

```mermaid
graph TB
subgraph "jmshop-api"
API[API模块]
Mapper[Mapper接口]
Service[Service实现]
end
subgraph "jmshop-common"
Common[公共模块]
BaseMapper[BaseMapper]
BaseServiceImpl[BaseServiceImpl]
end
subgraph "resources"
MapperXML[XML映射文件]
MybatisConfig[MyBatis配置]
end
API --> Mapper
API --> Service
Service --> Mapper
Common --> BaseMapper
Common --> BaseServiceImpl
Mapper --> MapperXML
API --> MybatisConfig
```

**图源**  
- [MybatisPlusConfig.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/config/MybatisPlusConfig.java)
- [YxStoreProductMapper.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/shop/mapper/YxStoreProductMapper.java)
- [YxStoreProductMapper.xml](file://mall-admin-server/jmshop-api/src/main/resources/mapper/shop/YxStoreProductMapper.xml)

**节源**  
- [MybatisPlusConfig.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/config/MybatisPlusConfig.java)
- [YxStoreProductMapper.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/shop/mapper/YxStoreProductMapper.java)

## 核心组件
本项目中的MyBatis-Plus核心组件包括BaseMapper接口、BaseServiceImpl抽象类、分页插件配置以及具体的Mapper接口实现。这些组件共同构成了数据访问层的基础架构，提供了通用的CRUD操作和分页功能。

**节源**  
- [BaseMapper.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/base/BaseMapper.java)
- [BaseServiceImpl.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/common/service/impl/BaseServiceImpl.java)
- [MybatisPlusConfig.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/config/MybatisPlusConfig.java)

## 架构概述
MyBatis-Plus在本项目中的架构设计遵循了典型的分层模式，包括Mapper层、Service层和Controller层。Mapper层通过继承BaseMapper获得通用CRUD方法，Service层通过继承BaseServiceImpl获得分页和查询功能，同时可以调用Mapper接口执行自定义SQL操作。

```mermaid
graph TD
Controller[Controller层] --> Service[Service层]
Service --> Mapper[Mapper层]
Mapper --> Database[(数据库)]
BaseMapper[BaseMapper] --> Mapper
BaseServiceImpl[BaseServiceImpl] --> Service
PaginationInterceptor[分页插件] --> Service
```

**图源**  
- [BaseMapper.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/base/BaseMapper.java)
- [BaseServiceImpl.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/common/service/impl/BaseServiceImpl.java)
- [MybatisPlusConfig.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/config/MybatisPlusConfig.java)

## 详细组件分析

### BaseMapper继承机制分析
在本项目中，所有Mapper接口都继承自MyBatis-Plus的BaseMapper，从而获得通用的CRUD方法。以YxStoreProductMapper为例，它继承了BaseMapper<YxStoreProduct>，自动获得了insert、delete、update、select等基本操作方法。

```mermaid
classDiagram
class BaseMapper {
+int insert(T entity)
+int deleteById(Serializable id)
+int updateById(T entity)
+T selectById(Serializable id)
+List<T> selectList(Wrapper<T> queryWrapper)
+IPage<T> selectPage(IPage<T> page, Wrapper<T> queryWrapper)
}
class YxStoreProductMapper {
+YxStoreProductQueryVo getYxStoreProductById(Serializable id)
+IPage<YxStoreProductQueryVo> getYxStoreProductPageList(Page page, YxStoreProductQueryParam param)
+int decStockIncSales(int num, int productId)
+int incStockDecSales(int num, int productId)
}
BaseMapper <|-- YxStoreProductMapper : "继承"
```

**图源**  
- [BaseMapper.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/base/BaseMapper.java)
- [YxStoreProductMapper.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/shop/mapper/YxStoreProductMapper.java)

**节源**  
- [YxStoreProductMapper.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/shop/mapper/YxStoreProductMapper.java)

### XML映射文件编写规范
本项目中的XML映射文件遵循了MyBatis的标准规范，使用了动态SQL标签来构建复杂的查询语句。以YxStoreProductMapper.xml为例，文件中定义了通用的查询结果列，并使用了<sql>标签进行代码复用。

```mermaid
flowchart TD
Start([XML映射文件]) --> BaseColumn["定义Base_Column_List"]
BaseColumn --> SelectById["定义getById查询"]
BaseColumn --> SelectPage["定义getPageList查询"]
BaseColumn --> CustomQuery["定义自定义查询"]
SelectById --> IncludeBase["包含Base_Column_List"]
SelectPage --> IncludeBase
CustomQuery --> IncludeBase
IncludeBase --> End([完成])
```

**图源**  
- [YxStoreProductMapper.xml](file://mall-admin-server/jmshop-api/src/main/resources/mapper/shop/YxStoreProductMapper.xml)

**节源**  
- [YxStoreProductMapper.xml](file://mall-admin-server/jmshop-api/src/main/resources/mapper/shop/YxStoreProductMapper.xml)

### Service层调用Mapper接口
在Service层中，通过@Autowired注入Mapper接口实例，然后调用其方法执行数据库操作。以YxStoreProductServiceImpl为例，该类通过继承BaseServiceImpl获得了基本的CRUD功能，同时注入YxStoreProductMapper来执行自定义的SQL操作。

```mermaid
sequenceDiagram
participant Service as "YxStoreProductServiceImpl"
participant Mapper as "YxStoreProductMapper"
participant XML as "YxStoreProductMapper.xml"
Service->>Mapper : getYxStoreProductPageList()
Mapper->>XML : 执行SQL查询
XML-->>Mapper : 返回查询结果
Mapper-->>Service : 返回IPage<YxStoreProductQueryVo>
Service->>Service : 处理结果数据
Service-->>Controller : 返回Paging对象
```

**图源**  
- [YxStoreProductServiceImpl.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/shop/service/impl/YxStoreProductServiceImpl.java)
- [YxStoreProductMapper.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/shop/mapper/YxStoreProductMapper.java)
- [YxStoreProductMapper.xml](file://mall-admin-server/jmshop-api/src/main/resources/mapper/shop/YxStoreProductMapper.xml)

**节源**  
- [YxStoreProductServiceImpl.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/modules/shop/service/impl/YxStoreProductServiceImpl.java)

## 依赖分析
MyBatis-Plus在本项目中的依赖关系清晰，主要依赖包括MyBatis-Plus核心库、分页插件、以及项目内部的基础组件。这些依赖共同支持了数据访问层的功能实现。

```mermaid
graph TD
MybatisPlus[MyBatis-Plus] --> PaginationInterceptor[分页插件]
MybatisPlus --> BaseMapper[BaseMapper]
MybatisPlus --> ServiceImpl[ServiceImpl]
BaseMapper --> YxStoreProductMapper[YxStoreProductMapper]
ServiceImpl --> BaseServiceImpl[BaseServiceImpl]
BaseServiceImpl --> YxStoreProductServiceImpl[YxStoreProductServiceImpl]
YxStoreProductMapper --> YxStoreProductMapperXML[YxStoreProductMapper.xml]
YxStoreProductServiceImpl --> YxStoreProductMapper
```

**图源**  
- [MybatisPlusConfig.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/config/MybatisPlusConfig.java)
- [BaseMapper.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/base/BaseMapper.java)
- [BaseServiceImpl.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/common/service/impl/BaseServiceImpl.java)

**节源**  
- [MybatisPlusConfig.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/config/MybatisPlusConfig.java)
- [BaseMapper.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/base/BaseMapper.java)
- [BaseServiceImpl.java](file://mall-admin-server/jmshop-common/src/main/java/co/xiaoxiang/common/service/impl/BaseServiceImpl.java)

## 性能考虑
本项目在MyBatis-Plus的使用中充分考虑了性能优化。通过分页插件实现了高效的数据分页查询，避免了全表扫描。同时，在XML映射文件中使用了合理的索引和查询条件，确保了查询效率。

## 故障排除指南
在使用MyBatis-Plus时，常见的问题包括分页插件未生效、XML映射文件路径错误、Mapper接口无法注入等。解决这些问题的关键是检查配置文件是否正确，确保Mapper接口被正确扫描，以及XML文件路径与namespace匹配。

**节源**  
- [MybatisPlusConfig.java](file://mall-admin-server/jmshop-api/src/main/java/co/xiaoxiang/config/MybatisPlusConfig.java)
- [YxStoreProductMapper.xml](file://mall-admin-server/jmshop-api/src/main/resources/mapper/shop/YxStoreProductMapper.xml)

## 结论
本项目成功集成了MyBatis-Plus，通过BaseMapper继承机制和BaseServiceImpl抽象类，实现了通用CRUD操作和分页功能。XML映射文件的规范编写和动态SQL的使用，使得复杂查询变得简单高效。这种设计不仅提高了开发效率，也保证了代码的可维护性和性能。