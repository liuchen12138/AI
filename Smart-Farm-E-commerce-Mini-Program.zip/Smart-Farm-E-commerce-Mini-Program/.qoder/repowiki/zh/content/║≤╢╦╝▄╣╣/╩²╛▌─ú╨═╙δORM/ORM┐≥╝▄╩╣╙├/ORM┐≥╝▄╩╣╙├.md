# ORM框架使用

<cite>
**本文档引用文件**  
- [YxStoreProductRepository.java](file://mall-admin-server\jmshop-shop\src\main\java\co\xiaoxiang\modules\shop\repository\YxStoreProductRepository.java)
- [YxStoreProductMapper.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\shop\mapper\YxStoreProductMapper.java)
- [YxStoreProductMapper.xml](file://mall-admin-server\jmshop-api\src\main\resources\mapper\shop\YxStoreProductMapper.xml)
- [YxStoreProductServiceImpl.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\shop\service\impl\YxStoreProductServiceImpl.java)
- [YxStoreProduct.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\shop\entity\YxStoreProduct.java)
- [MybatisPlusConfig.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\config\MybatisPlusConfig.java)
- [RedisConfig.java](file://mall-admin-server\jmshop-common\src\main\java\co\xiaoxiang\config\RedisConfig.java)
- [application-dev.yml](file://mall-admin-server\jmshop-system\src\main\resources\config\application-dev.yml)
</cite>

## 目录
1. [引言](#引言)
2. [JPA Repository 使用详解](#jpa-repository-使用详解)
3. [MyBatis-Plus 使用详解](#mybatis-plus-使用详解)
4. [两种框架对比与适用场景](#两种框架对比与适用场景)
5. [Service 层调用示例](#service-层调用示例)
6. [性能优化策略](#性能优化策略)
7. [结论](#结论)

## 引言

本项目采用 JPA 和 MyBatis-Plus 混合使用的 ORM 策略，以充分发挥两种框架的优势。JPA 用于处理简单的 CRUD 操作，提供声明式的数据访问方式；MyBatis-Plus 则用于处理复杂的动态 SQL 查询，提供了更高的灵活性和控制力。这种混合架构在保证开发效率的同时，也满足了复杂业务场景下的性能需求。

## JPA Repository 使用详解

### 方法命名约定

JPA Repository 通过方法命名约定自动生成查询语句。例如，在 `YxStoreProductRepository` 接口中，`findByStoreCategoryAndIsDel` 方法会根据 `storeCategory` 和 `isDel` 字段生成对应的查询条件。

### 自定义查询

对于复杂的查询需求，可以使用 `@Query` 注解编写原生 SQL 或 JPQL 查询。例如：

```java
@Query(value = "update yx_store_product set is_show = ?1 where id = ?2", nativeQuery = true)
void updateOnsale(int status, Integer id);
```

此方法用于更新商品的上架状态，通过 `nativeQuery = true` 指定使用原生 SQL。

### 分页处理

JPA 提供了 `Pageable` 接口来支持分页查询。在 Repository 接口中定义方法时，可以将 `Pageable` 作为参数传入，Spring Data JPA 会自动处理分页逻辑。

**代码片段路径**
- [YxStoreProductRepository.java#L21-L76](file://mall-admin-server\jmshop-shop\src\main\java\co\xiaoxiang\modules\shop\repository\YxStoreProductRepository.java#L21-L76)

## MyBatis-Plus 使用详解

### Mapper 接口与 XML 映射文件协作

MyBatis-Plus 的 Mapper 接口与 XML 映射文件协同工作。Mapper 接口定义方法签名，XML 文件则包含具体的 SQL 语句。例如，`YxStoreProductMapper` 接口中的 `getYxStoreProductById` 方法对应 `YxStoreProductMapper.xml` 中的 `<select>` 标签。

### 复杂 SQL 查询实现

在 `YxStoreProductMapper.xml` 中，可以编写复杂的 SQL 查询，包括多表连接、子查询等。例如：

```xml
<select id="getYxStoreProductByTemplateId" resultType="co.xiaoxiang.modules.shop.web.vo.YxStoreProductQueryVo" parameterType="String">
    select a.id, a.mer_id, a.image,a.video,haibao_image,a.slider_image,IFNULL(b.product_name,a.store_name) as store_name,...
    from yx_store_product a,
    yx_product_template_item b
    where a.id=b.product_id and b.template_id in (${cateId})
</select>
```

此查询通过连接 `yx_store_product` 和 `yx_product_template_item` 表，根据模板 ID 获取商品信息。

**代码片段路径**
- [YxStoreProductMapper.java#L24-L67](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\shop\mapper\YxStoreProductMapper.java#L24-L67)
- [YxStoreProductMapper.xml#L1-L50](file://mall-admin-server\jmshop-api\src\main\resources\mapper\shop\YxStoreProductMapper.xml#L1-L50)

## 两种框架对比与适用场景

| 特性 | JPA | MyBatis-Plus |
| --- | --- | --- |
| **学习曲线** | 较陡峭 | 较平缓 |
| **开发效率** | 高（CRUD） | 高（复杂查询） |
| **灵活性** | 低 | 高 |
| **性能** | 一般 | 高 |
| **适用场景** | 简单 CRUD 操作 | 复杂动态 SQL 查询 |

JPA 适用于简单的增删改查操作，能够快速生成代码，减少重复劳动。而 MyBatis-Plus 更适合处理复杂的查询需求，如多表连接、动态条件等。

## Service 层调用示例

在 `YxStoreProductServiceImpl` 中，Service 层同时调用了 JPA 和 MyBatis-Plus 的功能。例如，`getGoodsList` 方法使用 MyBatis-Plus 的分页插件进行分页查询，而 `updateOnsale` 方法则通过 JPA Repository 更新商品状态。

```java
@Override
public List<YxStoreProductQueryVo> getGoodsList(YxStoreProductQueryParam productQueryParam) {
    // 使用 MyBatis-Plus 进行分页查询
    IPage<YxStoreProduct> pageList = yxStoreProductMapper.selectPage(pageModel, wrapper);
    ...
}
```

**代码片段路径**
- [YxStoreProductServiceImpl.java#L237-L315](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\shop\service\impl\YxStoreProductServiceImpl.java#L237-L315)

## 性能优化策略

### 懒加载

通过 `@OneToMany` 和 `@ManyToOne` 等注解的 `fetch = FetchType.LAZY` 属性，实现关联对象的懒加载，避免一次性加载过多数据。

### 缓存策略

项目中使用 Redis 作为二级缓存，通过 `@Cacheable` 注解缓存查询结果，减少数据库访问次数。Redis 的默认过期时间为 2 小时。

```java
@Bean
public RedisCacheConfiguration redisCacheConfiguration(){
    return RedisCacheConfiguration.defaultCacheConfig()
        .serializeValuesWith(RedisSerializationContext.SerializationPair.fromSerializer(fastJsonRedisSerializer))
        .entryTtl(Duration.ofHours(2));
}
```

### SQL 优化

- 使用索引优化查询性能。
- 避免 N+1 查询问题，使用 `JOIN` 一次性获取所需数据。
- 对于大数据量的查询，采用分页技术，限制返回结果的数量。

**代码片段路径**
- [RedisConfig.java#L48-L54](file://mall-admin-server\jmshop-common\src\main\java\co\xiaoxiang\config\RedisConfig.java#L48-L54)
- [application-dev.yml#L42-L45](file://mall-admin-server\jmshop-system\src\main\resources\config\application-dev.yml#L42-L45)

## 结论

本项目通过 JPA 和 MyBatis-Plus 的混合使用，实现了高效且灵活的数据访问层。JPA 适用于简单的 CRUD 操作，提高了开发效率；MyBatis-Plus 则解决了复杂查询的需求，保证了系统的性能。结合 Redis 缓存和 SQL 优化策略，进一步提升了系统的响应速度和稳定性。这种混合架构为电商小程序的高并发场景提供了坚实的技术支持。