# JPA使用

<cite>
**本文档引用的文件**   
- [YxStoreProduct.java](file://mall-admin-server\jmshop-shop\src\main\java\co\xiaoxiang\modules\shop\domain\YxStoreProduct.java)
- [YxStoreProductRepository.java](file://mall-admin-server\jmshop-shop\src\main\java\co\xiaoxiang\modules\shop\repository\YxStoreProductRepository.java)
- [YxStoreProductServiceImpl.java](file://mall-admin-server\jmshop-shop\src\main\java\co\xiaoxiang\modules\shop\service\impl\YxStoreProductServiceImpl.java)
- [BaseEntity.java](file://mall-admin-server\jmshop-common\src\main\java\co\xiaoxiang\base\BaseEntity.java)
- [Visits.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\monitor\domain\Visits.java)
- [VisitsRepository.java](file://mall-admin-server\jmshop-api\src\main\java\co\xiaoxiang\modules\monitor\repository\VisitsRepository.java)
</cite>

## 目录
1. [简介](#简介)
2. [JPA实体类配置](#jpa实体类配置)
3. [JPA Repository接口定义](#jpa-repository接口定义)
4. [自定义查询与原生SQL](#自定义查询与原生sql)
5. [分页与排序实现](#分页与排序实现)
6. [Service层中的Repository调用](#service层中的repository调用)
7. [懒加载与急加载策略](#懒加载与急加载策略)
8. [事务管理](#事务管理)
9. [性能优化技巧](#性能优化技巧)
10. [与其他组件的集成](#与其他组件的集成)
11. [CRUD操作优势与适用场景](#crud操作优势与适用场景)

## 简介
本项目采用Spring Data JPA作为持久层框架，实现了对数据库的高效访问和管理。JPA（Java Persistence API）提供了一套标准的ORM（对象关系映射）规范，使得开发者可以通过面向对象的方式操作数据库，而无需编写繁琐的SQL语句。在本项目中，JPA被广泛应用于商品管理、用户管理、订单处理等多个模块，极大地提高了开发效率和代码可维护性。

## JPA实体类配置
JPA实体类是数据库表与Java对象之间的桥梁，通过注解配置实现映射关系。在本项目中，`YxStoreProduct`类作为商品实体的代表，展示了JPA注解的典型用法。

### @Entity与@Table注解
`@Entity`注解标识一个类为JPA实体，表示该类将被持久化到数据库中。`@Table`注解用于指定实体对应的数据库表名。例如，在`YxStoreProduct`类中：
```java
@Entity
@Table(name="yx_store_product")
public class YxStoreProduct implements Serializable {
    // 实体属性
}
```
这里`@Entity`表明`YxStoreProduct`是一个JPA实体，`@Table(name="yx_store_product")`指定了该实体对应数据库中的`yx_store_product`表。

### @Id与@GeneratedValue注解
`@Id`注解用于标识实体的主键字段，`@GeneratedValue`注解则用于指定主键的生成策略。在`YxStoreProduct`类中，主键配置如下：
```java
@Id
@Column(name = "id")
private Integer id;
```
虽然此处未显式使用`@GeneratedValue`，但根据项目上下文，主键的生成可能依赖于数据库自身的自增机制或通过其他方式实现。对于需要自动生成主键的情况，可以使用`@GeneratedValue(strategy = GenerationType.IDENTITY)`来指定使用数据库的自增策略。

### 字段映射与约束
除了主键外，实体类中的其他字段也需要通过`@Column`注解进行映射，并可附加各种约束条件。例如：
```java
@Column(name = "store_name", nullable = false)
@NotBlank(message = "请填写商品名称")
private String storeName;
```
这里`@Column`指定了字段名和是否允许为空，`@NotBlank`是Bean Validation提供的注解，用于确保字段值不为空白。

### 关联映射
JPA支持多种关联映射，如一对一、一对多、多对一和多对多。在`YxStoreProduct`类中，通过`@ManyToOne`注解实现了与`YxStoreCategory`类的多对一关联：
```java
@ManyToOne(fetch=FetchType.LAZY, optional = false)
@JoinColumn(name = "cate_id")
@NotFound(action= NotFoundAction.IGNORE)
private YxStoreCategory storeCategory;
```
`fetch=FetchType.LAZY`表示采用懒加载策略，`optional = false`表示该关联不能为空，`@JoinColumn`指定了外键列名，`@NotFound`注解用于处理关联对象不存在的情况。

**Section sources**
- [YxStoreProduct.java](file://mall-admin-server\jmshop-shop\src\main\java\co\xiaoxiang\modules\shop\domain\YxStoreProduct.java#L22-L254)

## JPA Repository接口定义
JPA Repository接口是数据访问的核心，通过继承`JpaRepository`接口，可以获得丰富的CRUD操作方法。在本项目中，`YxStoreProductRepository`接口展示了如何定义和使用Repository。

### 继承JpaRepository
`YxStoreProductRepository`接口继承了`JpaRepository<YxStoreProduct, Integer>`，这使得它自动拥有了基本的增删改查功能：
```java
public interface YxStoreProductRepository extends JpaRepository<YxStoreProduct, Integer>, JpaSpecificationExecutor {
    // 自定义方法
}
```
`JpaRepository`提供了诸如`save`、`deleteById`、`findById`等方法，极大地简化了数据访问代码。

### 方法命名约定
Spring Data JPA支持通过方法名自动解析查询逻辑，遵循一定的命名约定。例如：
```java
List<YxStoreProduct> findByStoreCategoryAndIsDel(YxStoreCategory storeCategory, int isDel);
```
此方法名会被解析为一个查询，查找指定分类且删除状态为`isDel`的商品列表。方法名中的`findBy`表示查询操作，`StoreCategory`和`IsDel`分别对应实体类中的属性名，`And`连接多个条件。

### JpaSpecificationExecutor扩展
`JpaSpecificationExecutor`接口提供了更灵活的查询能力，支持动态构建查询条件。在`YxStoreProductServiceImpl`中，通过`QueryHelp.getPredicate`方法实现了复杂的查询逻辑：
```java
Page<YxStoreProduct> page = yxStoreProductRepository
    .findAll((root, criteriaQuery, criteriaBuilder) -> QueryHelp.getPredicate(root, criteria, criteriaBuilder), pageable);
```
这种方式允许根据运行时参数动态生成查询条件，非常适合实现分页查询和过滤功能。

**Section sources**
- [YxStoreProductRepository.java](file://mall-admin-server\jmshop-shop\src\main\java\co\xiaoxiang\modules\shop\repository\YxStoreProductRepository.java#L21-L77)

## 自定义查询与原生SQL
当标准的Repository方法无法满足需求时，可以通过`@Query`注解定义自定义查询，包括JPQL和原生SQL。

### 使用@Query注解
`@Query`注解允许开发者编写自定义的查询语句，既可以是JPQL（Java Persistence Query Language），也可以是原生SQL。在`YxStoreProductRepository`中，多个更新操作使用了原生SQL：
```java
@Modifying
@Transactional
@Query(value = "update yx_store_product set is_show = ?1 where id = ?2", nativeQuery = true)
void updateOnsale(int status, Integer id);
```
`nativeQuery = true`表示使用原生SQL，`?1`和`?2`是参数占位符，对应方法参数。`@Modifying`注解标记这是一个修改操作，需要配合`@Transactional`注解确保事务性。

### 参数绑定
在自定义查询中，参数可以通过位置（如`?1`）或名称（如`:paramName`）进行绑定。后者更加直观且易于维护：
```java
@Query(value = "SELECT * FROM yx_store_product where id in ?1", nativeQuery = true)
List<YxStoreProduct> findByIds(List<String> idList);
```
此方法接受一个ID列表作为参数，查询对应的商品记录。

**Section sources**
- [YxStoreProductRepository.java](file://mall-admin-server\jmshop-shop\src\main\java\co\xiaoxiang\modules\shop\repository\YxStoreProductRepository.java#L24-L76)

## 分页与排序实现
分页与排序是Web应用中常见的需求，Spring Data JPA提供了便捷的支持。

### Pageable接口
`Pageable`接口封装了分页和排序信息，通常作为Repository方法的参数。在`YxStoreProductServiceImpl`中，查询方法接收`Pageable`参数：
```java
public Map<String, Object> queryAll(YxStoreProductQueryCriteria criteria, Pageable pageable) {
    Page<YxStoreProduct> page = yxStoreProductRepository
        .findAll((root, criteriaQuery, criteriaBuilder) -> QueryHelp.getPredicate(root, criteria, criteriaBuilder), pageable);
    // 处理分页结果
}
```
`Pageable`对象包含了页码、每页大小和排序规则等信息，`Page`对象则封装了查询结果和分页元数据。

### 排序规则
排序可以通过`Sort`对象或直接在`Pageable`中指定。例如，创建一个按`sort`字段升序排列的`Pageable`：
```java
Pageable pageable = PageRequest.of(pageNumber, pageSize, Sort.by("sort").ascending());
```

**Section sources**
- [YxStoreProductServiceImpl.java](file://mall-admin-server\jmshop-shop\src\main\java\co\xiaoxiang\modules\shop\service\impl\YxStoreProductServiceImpl.java#L77-L105)

## Service层中的Repository调用
Service层负责业务逻辑的处理，通过注入Repository实现数据访问。

### 依赖注入
在`YxStoreProductServiceImpl`中，通过构造函数注入`YxStoreProductRepository`：
```java
@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true, rollbackFor = Exception.class)
public class YxStoreProductServiceImpl implements YxStoreProductService {

    private final YxStoreProductRepository yxStoreProductRepository;

    public YxStoreProductServiceImpl(YxStoreProductRepository yxStoreProductRepository) {
        this.yxStoreProductRepository = yxStoreProductRepository;
    }
    // 业务方法
}
```
`@Service`注解标识该类为服务组件，`@Transactional`注解定义了事务边界。

### 业务方法实现
业务方法通过调用Repository提供的方法完成数据操作。例如，创建商品的方法：
```java
@Override
@Transactional(rollbackFor = Exception.class)
public YxStoreProductDTO create(YxStoreProduct resources) {
    return yxStoreProductMapper.toDto(yxStoreProductRepository.save(resources));
}
```
`@Transactional(rollbackFor = Exception.class)`确保在发生异常时回滚事务，`save`方法保存实体并返回持久化后的对象。

**Section sources**
- [YxStoreProductServiceImpl.java](file://mall-admin-server\jmshop-shop\src\main\java\co\xiaoxiang\modules\shop\service\impl\YxStoreProductServiceImpl.java#L46-L126)

## 懒加载与急加载策略
JPA提供了懒加载和急加载两种关联加载策略，以平衡性能和数据完整性。

### FetchType.LAZY
懒加载意味着关联对象在首次访问时才从数据库加载。在`YxStoreProduct`类中，`storeCategory`字段使用了懒加载：
```java
@ManyToOne(fetch=FetchType.LAZY, optional = false)
@JoinColumn(name = "cate_id")
private YxStoreCategory storeCategory;
```
这种方式可以减少初始查询的负载，但需要注意避免N+1查询问题，即在循环中频繁访问未加载的关联对象。

### FetchType.EAGER
急加载则在加载主实体时一并加载关联对象。虽然简化了数据访问，但可能导致不必要的数据传输。选择合适的加载策略需根据具体业务场景权衡。

**Section sources**
- [YxStoreProduct.java](file://mall-admin-server\jmshop-shop\src\main\java\co\xiaoxiang\modules\shop\domain\YxStoreProduct.java#L76-L79)

## 事务管理
事务管理确保数据的一致性和完整性，Spring提供了声明式事务管理。

### @Transactional注解
`@Transactional`注解可以应用于类或方法级别，定义事务的边界和行为。在`YxStoreProductServiceImpl`中，更新操作使用了事务：
```java
@Override
@Transactional(rollbackFor = Exception.class)
public void update(YxStoreProduct resources) {
    // 更新逻辑
}
```
`rollbackFor = Exception.class`表示在抛出任何异常时回滚事务，保证数据一致性。

### 事务传播行为
`@Transactional(propagation = Propagation.SUPPORTS)`表示当前方法支持现有事务，若无事务则以非事务方式执行。不同的传播行为适用于不同的业务场景。

**Section sources**
- [YxStoreProductServiceImpl.java](file://mall-admin-server\jmshop-shop\src\main\java\co\xiaoxiang\modules\shop\service\impl\YxStoreProductServiceImpl.java#L47-L136)

## 性能优化技巧
为了提高应用性能，JPA提供了一些优化手段。

### 批量操作
对于大量数据的插入或更新，使用批量操作可以显著提升性能。虽然本项目中未直接展示，但可通过配置`spring.jpa.properties.hibernate.jdbc.batch_size`启用批量处理。

### 查询优化
避免N+1查询问题，使用`JOIN FETCH`一次性加载关联对象。例如：
```java
@Query("SELECT p FROM YxStoreProduct p JOIN FETCH p.storeCategory WHERE p.id = :id")
Optional<YxStoreProduct> findByIdWithCategory(@Param("id") Integer id);
```

### 缓存机制
利用一级缓存（Session级别）和二级缓存（SessionFactory级别）减少数据库访问次数。合理配置缓存策略可大幅提升读取性能。

## 与其他组件的集成
JPA与Spring生态中的其他组件无缝集成，如Spring Security、Spring Cache等。

### Spring Data JPA
Spring Data JPA进一步简化了Repository的开发，通过方法名解析和`@Query`注解，减少了模板代码的编写。

### MapStruct
在`YxStoreProductServiceImpl`中，使用MapStruct进行DTO与实体之间的转换：
```java
return yxStoreProductMapper.toDto(yxStoreProductRepository.save(resources));
```
`YxStoreProductMapper`接口定义了转换逻辑，自动生成实现代码，提高了类型安全性和性能。

## CRUD操作优势与适用场景
JPA在实现CRUD操作方面具有明显优势，特别适用于以下场景：

### 优势
- **减少样板代码**：通过继承`JpaRepository`，自动获得基本的增删改查方法。
- **类型安全**：方法名解析和编译时检查减少了运行时错误。
- **易于测试**：Repository接口易于Mock，便于单元测试。
- **灵活性**：支持自定义查询和动态条件构建，适应复杂业务需求。

### 适用场景
- **中小型项目**：对于数据模型相对稳定、查询逻辑不复杂的项目，JPA能快速搭建数据访问层。
- **快速原型开发**：利用Spring Data JPA的自动功能，可以迅速实现功能原型。
- **需要高度抽象的数据访问**：当业务逻辑与数据访问需要清晰分离时，JPA提供了一层良好的抽象。

综上所述，JPA及其在Spring Data JPA中的实现，为本项目提供了强大而灵活的数据访问能力，既简化了开发工作，又保证了系统的可维护性和扩展性。